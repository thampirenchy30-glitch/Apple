---
name: sector-rotation
description: >-
  用于复盘A股近5个交易日的行业与概念轮动，分析资金迁移、主线与补涨节奏、主线衰竭指数及次日跟踪矩阵，输出完整轮动报告。不适用于单日收盘复盘或盘前概率推演。
---

# A股板块轮动与多周期实战作战导航引擎

> 基于“多周期尺度识别 ➡️ 电风扇无效轮动过滤 ➡️ 机构中军与游资龙头背离审计 ➡️ 真假高低切甄别 ➡️ 主线衰竭指数 (SEI) ➡️ 生命周期战法与禁忌矩阵 ➡️ 次日盘前跟踪矩阵”的实盘板块作战复盘框架。

执行分析前必须读取并遵循 [A股研究公共契约](references/common-research-contract.md) 与 [工具调用配方](references/tool-recipes.md)。

<!-- PROMPT_INCLUDE: references/common-research-contract.md -->

---

## 一、核心定位与实战作战体系

系统从单纯的“5 日资金流统计表”全面升级为“真假轮动甄别、多周期主线穿透与离散战法指南系统”，彻底解耦为四大实战层级：
1. **Layer 1 多周期尺度识别 (Multi-Timeframe Scope)**：
   破除“单一 5 日机械窗口”的周期错配，调用 `resolve_rotation_timeframe` 区分：
   - **超短脉冲 (1–3日)**：突发事件短命催化，次日 9:35 决断，破开盘价或分时均线坚决离场；
   - **题材波段 (5–10日)**：产业催化与情绪主升，依托 5 日均线滚动操作，高位滞涨切出；
   - **季度趋势大主线 (20–60日)**：产业革命与宏观大逻辑（如自主可控/AI算力），缩量回踩 10/20 日线属黄金加仓点，不以单周资金流出误判为衰竭。
2. **Layer 2 电风扇无效轮动过滤器 (Electric-Fan Rotation Filter)**：
   调用 `assess_rotation_effectiveness`，量化日内异动板块数与成交集中度：
   - 存量缩量市中，若出现 4 个以上板块日内乱窜但成交额占比低、涨停缺乏梯队，直接触发【无效轮动防诱多预警】，实战指令：管住手，严禁盘中追逐任何脉冲题材。
3. **Layer 3 中军 vs 龙头背离度审计 (Core-Leader Divergence)**：
   调用 `calculate_leader_core_divergence`，穿透板块内部撕裂：
   - 警惕“百亿中军破位出货、小票龙头硬顶连板”的假繁荣诱多陷阱；
   - 警惕“总龙头核按钮跌停 A 杀、后排杂毛虚假拉板掩护出货”的抽血陷阱。
4. **Layer 4 真假高低切审计与生命周期战法速查表**：
   - 仅认可“同主线产业链下游扩散”与“宏观大风格切换”两种有效高低切，坚决将无逻辑超跌杂毛一日游打上无效标签；
   - 针对板块生命周期阶段（启动/强化/加速/分歧/退潮），输出清清楚楚的“允许战法”与“操作禁忌”。

### 🗣️ 口语化自然语言意图映射 (Natural Language Intent Mapping)
当用户输入以下口语提问时，自动路由并激活本 Skill：
- **板块轮动**：“最近哪几个板块在轮动”、“这周主线是谁”、“主力资金最近几天在往哪跑”、“5日轮动怎么看”、“现在是不是电风扇行情”
- **高低切换**：“现在去哪个板块比较安全”、“高位题材还能不能追”、“有什么低位补涨板块推荐”、“现在是不是假高低切”
- **轮动指令**：“板块轮动”、“5日复盘”、“行业轮动”、“主线衰竭分析”、“中军龙头背离分析”

---

## 二、数据获取与多周期覆盖率审计

1. **时间锚定与周期适配**：以最近已收盘交易日（T日 15:00 完场数据）为锚点，以 T-4 至 T 日为主观察面，并由 `resolve_rotation_timeframe` 自适应扩展或收敛观察周期。
2. **工具调用路由**：优先调用 MCP `get_rotation_context`（入参 `days` / `sector_count`）获取指数走势、行业资金流、广度序列与主线板块量价；未挂载 MCP 时平滑降级为定向搜索。
3. **覆盖率门槛与量化分开关**：计划权重为 T日 40%、T-1日 30%、T-2日 20%、T-3与T-4各 5%。覆盖天数不足 3 日或有效权重低于 70% 时，强制禁用 5 日量化分，仅输出定性观察。此外，`coverage_audit.score_gate` 为 `disabled_qualitative_only` 时（分块覆盖率 <70%，**或缺失 `dominant_sectors_kline` 主线板块量价块**）同样不得输出精确量化分——即便其余三块齐全（75%）也不例外，避免在无主线证据下给出轮动评分。

---

## 三、核心量化模型与纯计算配方

模型负责特征归类与风险分档，精确计算统一调用 `scripts/calculate.py` 纯函数库：

### 1. 资金轮动 4 种状态转移矩阵
- **State 1: 主线主升**：核心板块成交占比 $\ge 8\%$，连续 3 日阳线，产业链共振齐涨；
- **State 2: 畏高切低/补涨**：核心主线高位滞涨，资金向同属性低位个股或细分产业链补涨扩散；
- **State 3: 避险防御**：题材高位杀跌退潮，资金向高股息、红利、大银行抱团防守；
- **State 4: 冰点衰退**：涨停 $<20$ 家，跌停蔓延，高位股连续 A 杀，维持防守等待出清。

### 2. 电风扇无效轮动过滤器 (`assess_rotation_effectiveness`)
- 输入日内异动板块数、领涨板块成交额占比与涨停聚集度；
- 输出 `rotation_type`: `mainline_focused`（主线聚焦）/ `electric_fan`（电风扇乱窜）/ `transitional`（过渡分歧）。
- **严禁缺参推断**：四个入参（`active_sectors_count` / `leader_turnover_share` / `limit_up_clusters` / `market_amount_ratio`）缺任一即返回 `N/A` 与 `unavailable`，报告须标注数据不足，**不得**凭默认值给出「主线聚焦 / 有效」结论。

### 3. 中军 vs 龙头背离审计 (`calculate_leader_core_divergence`)
- 判定 `healthy_resonance`（健康共振）、`core_desertion`（中军出货诱多）、`leader_collapse`（龙头溃退掩护）。

### 4. 主线衰竭与背离指数 (Sector Exhaustion Index, SEI: 0–100 分)
- 调用 `calculate_sector_exhaustion`（支持 auto_derive=True 客观推导）：
  - 0–30分【动能充沛】；31–60分【良性分歧】；61–80分【动能严重衰竭/高低切确立】；81–100分【全面退潮踩踏】。
  - 输出 `components` 三项子分，并标注 `calibration_status=uncalibrated`：子项权重 (40/30/30) 与分档阈值 (30/60/80) 为经验设定、未经历史样本校准，报告不得表述为已验证阈值；累积 ≥30 日后用 `eval_tracker` 主线状态台账复核。
- 调用 `map_exhaustion_to_lifecycle` 校验 SEI 分档与生命周期是否自洽（如 SEI=55 对应「良性分歧」，不得同时标注「高位分歧」）；`consistent=false` 时报告须披露 `conflict_note` 并以证据更充分的一方为准。

### 5. 板块成交容量门槛审计 (`validate_sector_capacity`)
- 量化板块日成交额及占全市场总成交额比例；可选传入 `market_amount_baseline_yi`（两市成交额基准），按 `baseline / 10000` 同比缩放绝对额门槛，避免放量市固定阈值失去区分度；
- `mega_mainline`（超级主线，支持百亿中军趋势重仓）需**同时**满足份额 $\ge 4.0\%$ 与绝对额达标（默认 $\ge 180$ 亿，随基准缩放）——修复历史「份额或绝对额任一达标」的 OR 后门；
- 份额 $\ge 2.0\%$ 或绝对额达标判定为 `standard_mainline`（标准主力题材）；其余为 `micro_niche`（微型游击题材），强制剥夺主线中军评级，标注仅适宜轻仓快进快出。

### 6. 资金跷跷板对立外溢矩阵 (`map_capital_seesaw_matrix`)
- 当主线进入加速赶顶或分歧退潮时，自动推演 A 股典型资金跷跷板（科技 vs 防御红利、资源 vs 新能源、超短 vs 大盘中字头），锁定外溢承接蓄水池。
- **本矩阵是基于关键词的规则推演，不是证据**：默认输出 `evidence_status=unverified_rule_only`，报告不得表述为已发生事实；仅当传入对手板块当日实测表现（`counterpart_change_pct` / `counterpart_net_flow_yi`）时才标记 `verified` 并附实测证据。`matched_keywords` 用于披露命中的关键词便于审计。

### 7. 板块资金迁移矩阵 (`calculate_rotation_migration`)
- 接收 T-4 至 T 逐日净流入排行，输出 `migration_matrix` 与 `persistence_ratio`，区分 `sustained_sectors`（持续流入的真正资金主线）与 `one_day_spike_sectors`（疑似单日爆量脉冲）；需 ≥3 个非空日，与覆盖率门槛一致。

### 8. 资金轮动 4 种状态转移矩阵 (`calculate_rotation_state`)
- State 1 主线主升 / State 2 畏高切低 / State 3 避险防御 / State 4 冰点衰退；
- State 2 额外输出 `high_to_low_status`：传入 `low_position_inflow=True` 记 `confirmed`、`False` 记 `failed`、缺省为 `unverified`，用于区分「切低成功」与「切低失败后直接退潮」。

---

## 四、报告输出模版与实战作战导航

按以下结构输出完整报告（缺失维度标注 `N/A`）：

1. **首屏摘要卡（必须置顶）**：
   严格遵循公共 Agent 输出协议：结论、逻辑状态（轮动 State）、当前位置（主线生命周期）、置信度、覆盖率、数据状态、最大风险和下一步观察；同时附带 `next_actions`（穿透个股、查看证据、生成报告）。
2. **零、多周期主线定调、容量门槛与电风扇真伪轮动判定**：
   - 明确当前市场属于【有效主线聚焦】还是【无效电风扇行情】；
   - 披露领涨板块资金容量等级（超级主线/标准题材/微型游击题材），杜绝无容量微型小票伪装大主线；
   - 披露领涨主线的时间尺度级别（超短脉冲 1–3 日 / 题材波段 5–10 日 / 季度大趋势 20–60 日）及匹配的防守基准线。
3. **一、主线中军与龙头背离深度解剖**：
   - 对比百亿容量中军与辨识度龙头的量价形态、均线趋势与资金流向，明确披露是否存在中军弃庄出货或孤桩诱多背离。
4. **二、板块生命周期与实操战法速查表 (Tactics & Taboos Matrix)**：
   针对当前主线所处阶段，列出具体实操指导：
   | 主线板块 | 生命周期阶段 | 推荐执行战法 | 绝对操作禁忌 |
   |:---|:---:|:---|:---|
   | 板块 A | 强化期/主升期 | 中军回踩 5 日线低吸、核心龙一分时转强加仓 | 严禁频繁调仓换股 |
   | 板块 B | 加速高潮期 | 持股锁仓、分批逢高止盈 | **严禁追高开仓后排跟风杂毛** |
   | 板块 C | 退潮衰竭期 | 仓位清零、反抽止损 | **严禁接飞刀、严禁抄底补仓** |
5. **三、真假高低切审计与资金跷跷板外溢预判 (Seesaw Matrix)**：
   - 严格审计当前低位异动是“同主线产业链下游扩散”还是“无逻辑超跌杂毛抽血”；
   - 输出《资金跷跷板外溢承接矩阵》：明确当老主线杀跌退潮时，资金最可能回流的对立对冲防守板块与次日观察点。
6. **四、次日盘前重点跟踪矩阵 (Next Day Watchlist)**：
   - 高低切潜力标的、老主线止跌观察点、高危回避方向及 9:25 集合竞价验证门槛（金额比与高开幅度）。
7. **标的穿透快捷指令**：用户回复 `诊断 [股票代码/名称]`，自动继承本轮动的总量环境与板块状态结论，直通 `stock-analysis`。
8. **跨 Skill 交接摘要 (Handoff JSON)**：文末输出下述 JSON，供盘前预测与个股诊断继承：

```json
{
  "report_type": "rotation",
  "as_of": "YYYY-MM-DD 15:00",
  "source_count": 0,
  "coverage": "0%",
  "scored_weight": "0%",
  "confidence": "高 | 中 | 低 | 数据不足",
  "regime_namespace": "rotation-state-1-4",
  "market_regime": "State 2: 畏高切低/补涨",
  "primary_sectors": ["候选主线1", "老主线"],
  "watchlist": ["候选先锋代码", "中军代码"],
  "risk_flags": ["主线SEI分值与评级", "电风扇轮动预警/中军背离预警"],
  "next_triggers": [
    {
      "id": "TRG-0925-01",
      "trigger_type": "竞价强弱",
      "condition": "次日候选主线竞价金额比>=1.5且开盘溢价",
      "status": "pending",
      "condition_above": "开盘集合竞价金额比>=2.0且高开>=2%",
      "action_above": "确认新主线启动，第一波低吸先锋切入",
      "condition_as_expected": "金额比在1.2-1.8之间，小幅高开或平开",
      "action_as_expected": "等待开盘后10:00前分时承接回踩确认",
      "condition_below": "竞价平开或低开，且竞价金额比<1.0",
      "action_below": "判定为虚假脉冲，放弃买入计划",
      "invalidation_condition": "板块龙头开盘直接跌停或中军大幅低开破位"
    }
  ]
}
```

---

## 五、交付与持久化

1. **交接摘要落盘与标准 Artifact**：调用 `python scripts/handoff_store.py write --stdin`（自动双写 rotation Artifact）。
2. **可选战报长图**：用户要求生成卡片时，调用 `python scripts/generate_report_card.py --type rotation --json report.json`。
3. **战术结论评估台账（可选持久化）**：为让结论可被次日证伪，收盘复盘后执行 `python scripts/eval_tracker.py record-daily --date <T> --rotation-type <类型> --divergence-type <类型>` 落盘当日结论，次日用 `reconcile-tactics` 回填 `confirmed/failed/unverifiable`，再用 `report-tactics` 输出历史命中率（`unverifiable` 不计入分母；可判定样本 <20 时仅供观察）。台账不可用时标注 `evaluation_status=emitted_only`，不影响专业分析完成。
