#!/usr/bin/env python3
"""
MarketGraph Financial MCP Server (Zero-Config, Protocol 1.0 Ready)
==================================================================
跨智能体通用 A 股金融数据 MCP 服务端 (Agent Plugins 1.0 标准)
- 零注册、免 Token、零第三方重依赖 (基于 Python 3.8+ 标准库)
- 主干直连腾讯证券 CDN (毫秒级实时盘口、估值、750日前复权K线、指数日K与ATR)
- 短线直连东方财富打板网关 (涨停池、连板天梯、炸板池与真实炸板率)
- 支持标准 JSON-RPC 2.0 stdio 协议 (兼容 Cursor / VS Code / Gemini / Claude)
"""

import sys
import json
import time
import math
import re
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime, date
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
PROJECT_ROOT = next(
    (
        parent for parent in Path(__file__).resolve().parents
        if (parent / "registry.json").is_file() or (parent / ".stock-prompt-runtime.json").is_file()
    ),
    Path(__file__).resolve().parents[2],
)
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from marketgraph_mcp.cache import (
    CACHE_STORE, CACHE_TTL_SECONDS, HISTORICAL_CACHE_TTL_SECONDS,
    get_cached, set_cached, ttl_for_history,
)
from marketgraph_mcp.symbols import (
    INDEX_ALIASES, INDEX_NAME_TO_KEY, normalize_date_str, normalize_symbol,
    resolve_index_keys, resolve_symbol_by_name,
)
from marketgraph_mcp.schemas import AVAILABLE_TOOLS
from marketgraph_mcp.transport import (
    ALLOWED_HTTP_HOSTS, BREAKER_COOLDOWN_SECONDS, BREAKER_FAILURE_THRESHOLD,
    HOST_MIN_INTERVAL_SECONDS, MAX_HTTP_RESPONSE_BYTES, USER_AGENT,
    _HOST_FAILURE_STATE, _HOST_LAST_REQUEST, _breaker_check,
    _breaker_record_failure, _breaker_record_success, _throttle_host, http_get,
)
from tools.agent_tools import (
    evaluate_prediction_tool,
    load_artifact_tool,
    render_report_tool,
    save_artifact_tool,
)
from tools.calculations.stock import (
    assess_wyckoff_applicability,
    classify_stock_archetype,
    resolve_stock_data_mode,
    select_stock_model,
    summarize_seat_evidence,
    validate_position_context,
)

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

# -----------------------------------------------------------------------------
# 1. 基础配置与轻量内存缓存 (TTL Cache，防止频繁请求)
# -----------------------------------------------------------------------------
def safe_float(val: Any, default: Optional[float] = 0.0) -> Optional[float]:
    try:
        if val is None or str(val).strip() == "":
            return default
        return float(val)
    except (ValueError, TypeError):
        return default


def em_dc_rows(payload: Any) -> List[Dict[str, Any]]:
    """安全提取东财 datacenter 返回的 result.data 行。

    东财对「无记录」与「频控」都会返回 {"result": null}。历史实现
    `.get("result", {}).get("data", [])` 在 result 键存在而值为 None 时会抛
    AttributeError，使「未上榜 / 无记录」这一正常分支永远不可达。此处显式判空。
    """
    if not isinstance(payload, dict):
        return []
    result = payload.get("result")
    if not isinstance(result, dict):
        return []
    data = result.get("data")
    return [row for row in data if isinstance(row, dict)] if isinstance(data, list) else []


# -----------------------------------------------------------------------------
# 2. 核心量化数据抓取与指标引擎 (腾讯证券 + 东方财富公开网关)
# -----------------------------------------------------------------------------
def breadth_red_ratio(breadth: Any) -> Optional[float]:
    """从市场广度信封中提取最新交易日的红盘率（%）。

    优先取精确全市场快照的 `red_rate`，缺失时由涨跌家数现算，均不可得返回 None。
    历史实现直接读取生产中从不存在的 `red_ratio` 键，恒取默认 50%，导致
    「指数涨但红盘率低」的二八分化冲突检测永不触发（死分支）。
    """
    if not isinstance(breadth, dict):
        return None
    snapshot = breadth.get("latest_exact_snapshot")
    if isinstance(snapshot, dict):
        value = safe_float(str(snapshot.get("red_rate", "")).rstrip("%"), None)
        if value is not None:
            return value
        up = safe_float(snapshot.get("up_count"), None)
        down = safe_float(snapshot.get("down_count"), None)
        if up is not None and down is not None and (up + down) > 0:
            return up / (up + down) * 100.0
    window = breadth.get("days_window")
    if isinstance(window, list) and window and isinstance(window[-1], dict):
        return safe_float(str(window[-1].get("red_rate", "")).rstrip("%"), None)
    return None


def normalize_date(value: Any) -> Optional[str]:
    """把 20261003 / 2026-10-03 / 2026-10-03 14:15:00 / 20261003141500 统一归一为 YYYY-MM-DD。"""
    if value is None:
        return None
    digits = "".join(ch for ch in str(value).strip() if ch.isdigit())
    if len(digits) < 8 or not 1990 <= int(digits[:4]) <= 2100:
        return None
    return f"{digits[:4]}-{digits[4:6]}-{digits[6:8]}"


def index_latest_date(index_result: Any) -> Optional[str]:
    """从 fetch_index_kline 结果取最新交易日（各指数 payload 的 date 最大值）。

    历史实现读取并不存在的顶层 `latest_date`，使上下文信封的 data_date 静默回落为
    今天，任何历史查询都会被标注为当日数据。
    """
    if not isinstance(index_result, dict):
        return None
    indices = index_result.get("indices")
    if not isinstance(indices, dict):
        return None
    dates = [normalize_date(item.get("date")) for item in indices.values() if isinstance(item, dict)]
    dates = [item for item in dates if item]
    return max(dates) if dates else None


def fetch_stock_quote(symbol: str) -> Dict[str, Any]:
    """获取个股实时行情与估值指标"""
    ts_code = normalize_symbol(symbol)
    cache_key = f"quote_{ts_code}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    url = f"https://qt.gtimg.cn/q={ts_code}"
    try:
        raw = http_get(url)
    except Exception as exc:
        return {"error": f"行情上游不可用: {type(exc).__name__}", "data_status": "unavailable"}
    if "~" not in raw:
        return {"error": f"未找到证券代码数据: {symbol}"}

    parts = raw.split("=")[1].strip('";\n').split("~")
    if len(parts) < 40:
        return {"error": f"行情数据格式不完整: {symbol}"}

    try:
        current_price = safe_float(parts[3], 0.0)
        yesterday_close = safe_float(parts[4], 0.0)
        open_price = safe_float(parts[5], 0.0)
        high_price = safe_float(parts[33], current_price) if len(parts) > 33 else current_price
        low_price = safe_float(parts[34], current_price) if len(parts) > 34 else current_price
        change_pct = safe_float(parts[32], 0.0) if len(parts) > 32 else 0.0
        turnover_rate = safe_float(parts[38], 0.0) if len(parts) > 38 else 0.0
        pe_ttm = safe_float(parts[39], None) if len(parts) > 39 else None
        pb = safe_float(parts[46], None) if len(parts) > 46 else None
        total_market_cap = safe_float(parts[45], None) if len(parts) > 45 else None  # 亿元
        float_market_cap = safe_float(parts[44], None) if len(parts) > 44 else None  # 亿元
        volume_hand = safe_float(parts[6], 0.0)  # 手
        turnover_amount = safe_float(parts[37], 0.0) if len(parts) > 37 else 0.0  # 万元
        turnover_billion = round(turnover_amount / 10000.0, 2)
        amplitude = safe_float(parts[43], 0.0) if len(parts) > 43 else 0.0
        # 容量中军特征: 流通市值/总市值 >= 200 亿且日成交额 >= 15 亿 (大额流动性承接)
        cap_val = float_market_cap if float_market_cap is not None else total_market_cap
        is_capacity_core = bool(cap_val is not None and cap_val >= 200.0 and turnover_billion >= 15.0)
        core_role_tag = "容量中军" if is_capacity_core else ("小盘高弹性" if cap_val is not None and cap_val < 50.0 else "常规标的")

        res = {
            "source": "P3_Tencent_Public_Gateway",
            "data_status": "ok",
            "symbol": symbol,
            "ts_code": ts_code,
            "name": parts[1] if len(parts) > 1 else symbol,
            "price": current_price,
            "change_pct": f"{change_pct:+.2f}%",
            "open": open_price,
            "close": current_price,
            "high": high_price,
            "low": low_price,
            "prev_close": yesterday_close,
            "turnover_rate": f"{turnover_rate:.2f}%",
            "amplitude": f"{amplitude:.2f}%",
            "volume_hand": volume_hand,
            "turnover_cny_wan": turnover_amount,
            "turnover_billion": turnover_billion,
            "pe_ttm": pe_ttm,
            "pb": pb,
            "total_market_cap_billion": total_market_cap,
            "float_market_cap_billion": float_market_cap,
            "is_capacity_core": is_capacity_core,
            "core_role_tag": core_role_tag,
            "as_of": parts[30] if len(parts) > 30 and len(parts[30]) >= 8 else datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        set_cached(cache_key, res)
        return res
    except Exception as e:
        return {"error": f"解析个股行情出错: {str(e)}"}


def fetch_index_daily_bars(ts_code: str, count: int) -> List[Dict[str, Any]]:
    """
    拉取指数日K原始序列 (多取1根用于计算首日涨跌幅)
    指数无复权概念，腾讯网关对指数代码返回 day 键 (个股才是 qfqday)
    """
    url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param={ts_code},day,,,{count + 1},qfq"
    raw = http_get(url)
    data = json.loads(raw)
    root = data.get("data", {}).get(ts_code, {})
    bars_raw = root.get("day") or []
    bars = []
    for row in bars_raw[-(count + 1):]:
        if len(row) >= 6:
            bars.append({
                "date": str(row[0]),
                "open": float(row[1]),
                "close": float(row[2]),
                "high": float(row[3]),
                "low": float(row[4]),
                "volume": float(row[5]),
            })
    return bars


def fetch_index_kline(indices: Optional[List[str]] = None, count: int = 5) -> Dict[str, Any]:
    """
    获取核心指数 (上证指数/深证成指/创业板指/中证全指/沪深300) 最近 N 个交易日的收盘与逐日涨跌幅
    直供 sector-rotation 全窗口指数强弱判别、daily-review 大盘定调与 stock-analysis L4 宽基基准
    (count 支持 130, 覆盖 L4 的 120 日相对强度窗口),
    弥补个股K线网关无法解析指数代码 (000001 会被解析为平安银行) 的确定性缺口
    """
    if not isinstance(count, int) or not 2 <= count <= 130:
        return {"error": "count 必须是 2 至 130 的整数", "data_status": "unavailable"}
    keys = resolve_index_keys(indices)
    if not keys:
        return {"error": "未识别到有效指数 (支持 SHCI/SZCI/CYB/CSIALL/HS300 或中文别名)", "data_status": "unavailable"}

    result: Dict[str, Any] = {}
    failures: List[str] = []
    for key in keys:
        ts_code, name = INDEX_ALIASES[key]
        cache_key = f"index_kline_{ts_code}_{count}"
        cached = get_cached(cache_key)
        if cached:
            result[key] = cached
            continue
        try:
            bars = fetch_index_daily_bars(ts_code, count)
            if len(bars) < 2:
                raise ValueError("K线根数不足")
            days = []
            for i in range(1, len(bars)):
                prev_close = bars[i - 1]["close"]
                cur = bars[i]
                if prev_close <= 0:
                    continue
                days.append({
                    "date": cur["date"],
                    "close": cur["close"],
                    "change_pct": f"{((cur['close'] - prev_close) / prev_close * 100):+.2f}%",
                })
            if not days:
                raise ValueError("涨跌幅序列为空")

            # 指数技术指标: ATR14 (Z_ATR 判档)、均线体系与 20 日高低 (空间点位候补)
            closes_full = [b["close"] for b in bars]
            highs_full = [b["high"] for b in bars]
            lows_full = [b["low"] for b in bars]
            n_bars = len(bars)
            atr14 = None
            if n_bars >= 15:
                trs = []
                for i in range(n_bars - 14, n_bars):
                    prev_close = closes_full[i - 1]
                    trs.append(max(highs_full[i] - lows_full[i], abs(highs_full[i] - prev_close), abs(lows_full[i] - prev_close)))
                atr14 = round(sum(trs) / 14.0, 2)
            latest_close = closes_full[-1]

            def index_ma(window: int) -> Optional[float]:
                return round(sum(closes_full[-window:]) / window, 2) if n_bars >= window else None

            payload = {
                "name": name,
                "ts_code": ts_code,
                "days": days[-count:],
                "latest_close": latest_close,
                "atr14": atr14,
                "atr14_pct": f"{(atr14 / latest_close * 100):.2f}%" if atr14 and latest_close > 0 else None,
                "ma5": index_ma(5),
                "ma20": index_ma(20),
                "ma60": index_ma(60),
                "high_20d": max(highs_full[-min(20, n_bars):]),
                "low_20d": min(lows_full[-min(20, n_bars):]),
            }
            set_cached(cache_key, payload, ttl=600)
            result[key] = payload
        except Exception:
            failures.append(name)

    if not result:
        return {
            "source": "P3_Tencent_Index_Kline",
            "data_status": "unavailable",
            "error": f"指数日K全部获取失败: {', '.join(failures) or '未知'}",
        }
    res = {
        "source": "P3_Tencent_Index_Kline",
        "data_status": "ok" if not failures else "partial",
        "indices": result,
        "summary": "；".join(
            f"{v['name']} 最新 {v['days'][-1]['date']} {v['days'][-1]['change_pct']}"
            for v in result.values()
        ),
    }
    if failures:
        res["unavailable_indices"] = failures
    return res


def aggregate_daily_to_weekly(bars: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    在内存中将前复权日K线无损聚合成周K线（0ms网络开销），计算周线均线系统与多周期共振趋势
    """
    if not bars:
        return {"data_status": "insufficient_data"}

    from collections import OrderedDict
    weeks_dict = OrderedDict()

    for bar in bars:
        date_str = bar.get("date", "")
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            iso_year, iso_week, _ = dt.isocalendar()
            key = (iso_year, iso_week)
        except Exception:
            key = date_str[:7]

        if key not in weeks_dict:
            weeks_dict[key] = []
        weeks_dict[key].append(bar)

    weekly_bars = []
    for key, day_list in weeks_dict.items():
        w_open = day_list[0]["open"]
        w_close = day_list[-1]["close"]
        w_high = max(d["high"] for d in day_list)
        w_low = min(d["low"] for d in day_list)
        w_vol = sum(d["volume"] for d in day_list)
        w_date = day_list[-1]["date"]
        weekly_bars.append({
            "date": w_date,
            "open": round(w_open, 2),
            "close": round(w_close, 2),
            "high": round(w_high, 2),
            "low": round(w_low, 2),
            "volume": round(w_vol, 2),
        })

    num_weeks = len(weekly_bars)
    if num_weeks == 0:
        return {"data_status": "insufficient_data"}

    w_closes = [wb["close"] for wb in weekly_bars]
    latest_w_close = w_closes[-1]

    # 周均线: MA10 (约50日线，中期波段趋势) / MA30 (约150日线，大级别牛熊分水岭)
    weekly_ma10 = round(sum(w_closes[-10:]) / 10.0, 2) if num_weeks >= 10 else None
    weekly_ma30 = round(sum(w_closes[-30:]) / 30.0, 2) if num_weeks >= 30 else None

    # 周线趋势状态判定
    if weekly_ma10 and weekly_ma30:
        if latest_w_close >= weekly_ma10 and weekly_ma10 >= weekly_ma30:
            weekly_alignment = "BULLISH_UPTREND"  # 周线多头排列，主升大趋势
        elif latest_w_close <= weekly_ma10 and weekly_ma10 <= weekly_ma30:
            weekly_alignment = "BEARISH_DOWNTREND"  # 周线空头排列，下行大趋势
        elif latest_w_close >= weekly_ma10 and weekly_ma10 < weekly_ma30:
            weekly_alignment = "REBOUND_TESTING_RESISTANCE"  # 周线超跌反弹，测试长期均线阻力
        else:
            weekly_alignment = "CONSOLIDATION"  # 周线震荡整理
    else:
        weekly_alignment = "NEUTRAL"

    # 周线高低区间 (近52周 / 约1年)
    w52_high = max([wb["high"] for wb in weekly_bars[-min(52, num_weeks):]])
    w52_low = min([wb["low"] for wb in weekly_bars[-min(52, num_weeks):]])

    return {
        "total_weeks": num_weeks,
        "latest_week_date": weekly_bars[-1]["date"],
        "latest_week_close": latest_w_close,
        "weekly_ma10": weekly_ma10,
        "weekly_ma30": weekly_ma30,
        "weekly_alignment": weekly_alignment,
        "bias_weekly_ma10": f"{((latest_w_close - weekly_ma10) / weekly_ma10 * 100):+.2f}%" if weekly_ma10 else "N/A",
        "bias_weekly_ma30": f"{((latest_w_close - weekly_ma30) / weekly_ma30 * 100):+.2f}%" if weekly_ma30 else "N/A",
        "high_52_weeks": w52_high,
        "low_52_weeks": w52_low,
        "summary": f"周线共振: 覆盖 {num_weeks} 周; 趋势定调: {weekly_alignment}; MA10: {weekly_ma10}, MA30: {weekly_ma30}",
    }


def compute_wyckoff_signals(
    bars: List[Dict[str, Any]],
    ma20: float,
    ma50: float,
    ma120: Optional[float],
    ma250: Optional[float],
    ma500: Optional[float],
    atr14: float,
    latest_close: float,
    bias_ma20: float,
    high_year: float,
    low_year: float,
    high_3y: float,
    low_3y: float,
    weekly_info: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """预计算三层威科夫时空模型（3年宏观大周期 + 周线共振大势 + 60日微观交易区间与量价触发），消除大模型数值对比幻觉"""
    valid_count = len(bars)
    if valid_count < 20:
        return {"data_status": "insufficient_bars"}

    highs = [b["high"] for b in bars]
    lows = [b["low"] for b in bars]
    volumes = [b["volume"] for b in bars]

    vol_ma20 = sum(volumes[-20:]) / 20.0
    latest_vol = volumes[-1]
    latest_high = highs[-1]
    latest_low = lows[-1]
    bar_range = latest_high - latest_low if latest_high > latest_low else 0.01

    # 1. 宏观威科夫大周期定调 (Macro Wyckoff Phase, 结合 3年大时空坐标与 MA250/MA500)
    range_3y = high_3y - low_3y if high_3y > low_3y else 1.0
    percentile_3y = round((latest_close - low_3y) / range_3y * 100, 1)

    year_range = high_year - low_year if high_year > low_year else 1.0
    year_percentile = round((latest_close - low_year) / year_range * 100, 1)

    bias_ma250 = round((latest_close - ma250) / ma250 * 100, 2) if ma250 else None
    bias_ma120 = round((latest_close - ma120) / ma120 * 100, 2) if ma120 else None
    bias_ma500 = round((latest_close - ma500) / ma500 * 100, 2) if ma500 else None

    macro_note = None
    if ma250 and ma500:
        if latest_close >= ma250 and ma250 >= ma500 * 0.98 and percentile_3y >= 50.0:
            macro_phase = "STAGE_2_MACRO_MARKUP_BULLISH"  # 站稳年线与两年线之上，3年大级别牛市主升
        elif latest_close <= ma250 and ma250 <= ma500 * 1.02 and percentile_3y <= 40.0:
            if percentile_3y <= 20.0:
                macro_phase = "STAGE_1_MACRO_ACCUMULATION"  # 3年历史大底部吸筹区 (铁底沉淀蓄势)
            else:
                macro_phase = "STAGE_4_MACRO_MARKDOWN_BEARISH"  # 3年大级别空头阴跌通道 (年线/两年线强压)
        elif percentile_3y <= 25.0:
            macro_phase = "STAGE_1_MACRO_ACCUMULATION"  # 3年周期极度低估与大吸筹区
        elif percentile_3y >= 85.0:
            macro_phase = "STAGE_3_MACRO_DISTRIBUTION"  # 3年高位筹码派发区 (天花板筑顶风险)
        else:
            macro_phase = "STAGE_REACCUMULATION_OR_CONSOLIDATION"  # 3年中继箱体震荡整理
    elif ma250:
        if latest_close >= ma250 and year_percentile >= 50.0:
            macro_phase = "STAGE_2_MARKUP_BULLISH"
        elif latest_close <= ma250 and year_percentile <= 40.0:
            macro_phase = "STAGE_1_MACRO_ACCUMULATION" if percentile_3y <= 25.0 else "STAGE_4_MARKDOWN_BEARISH"
        elif percentile_3y <= 25.0:
            macro_phase = "STAGE_1_MACRO_ACCUMULATION"
        elif percentile_3y >= 80.0:
            macro_phase = "STAGE_3_MACRO_DISTRIBUTION"
        else:
            macro_phase = "STAGE_REACCUMULATION_OR_CONSOLIDATION"
    else:
        # 无年线（有效K线不足 200 根）时，所谓「3年分位」并非真实 3 年窗口，证据不可靠。
        # 旧实现默认返回 STAGE_2_MARKUP_BULLISH（牛市主升），属乐观默认值：
        # 在缺少年线/两年线证据时不得断言大级别主升，改为显式标注不可判定。
        macro_phase = "STAGE_UNKNOWN_INSUFFICIENT_LONG_TERM"
        macro_note = "有效K线不足 200 根，缺少年线/两年线证据，宏观大周期阶段不可判定"

    # 2. 中微观局部交易区间 (Trading Range, 观察近 60 日震荡箱体)
    tr_window = min(60, valid_count)
    tr_high = max(highs[-tr_window:])
    tr_low = min(lows[-tr_window:])
    tr_span = tr_high - tr_low if tr_high > tr_low else 1.0
    tr_position_pct = round((latest_close - tr_low) / tr_span * 100, 1)

    if tr_position_pct <= 20.0:
        tr_location = "AT_SUPPORT_ICE"  # 紧贴近 60 日支撑冰线
    elif tr_position_pct >= 80.0:
        tr_location = "AT_RESISTANCE_CREEK"  # 紧贴近 60 日阻力跨溪线
    else:
        tr_location = "MID_RANGE"  # 处于交易区间中轴震荡

    # 3. 量价微观触发 (Spring / UT / 地量 / 放量)
    volume_dry_up = latest_vol < (vol_ma20 * 0.60)  # 地量：低于20日均量60%
    volume_expansion = latest_vol > (vol_ma20 * 1.80)  # 放量：高于20日均量1.8倍
    vol_ratio_to_ma20 = round(latest_vol / vol_ma20, 2) if vol_ma20 > 0 else 1.0

    min_prev_10_low = min(lows[-11:-1]) if len(lows) >= 11 else min(lows)
    lower_shadow = min(latest_close, bars[-1]["open"]) - latest_low
    spring_detected = bool(
        (latest_low < min_prev_10_low)
        and (lower_shadow / bar_range >= 0.50)
        and (latest_close > latest_low + bar_range * 0.40)
    )

    max_prev_10_high = max(highs[-11:-1]) if len(highs) >= 11 else max(highs)
    upper_shadow = latest_high - max(latest_close, bars[-1]["open"])
    upthrust_detected = bool(
        (latest_high >= max_prev_10_high)
        and (upper_shadow / bar_range >= 0.50)
        and (latest_close < latest_high - bar_range * 0.40)
    )

    recent_10_high = max(highs[-10:])
    recent_10_low = min(lows[-10:])
    range_10 = recent_10_high - recent_10_low
    absorption_detected = bool((range_10 <= 3.0 * atr14) and (latest_close >= ma20 * 0.97))

    # 4. 均线乖离状态
    if bias_ma20 > 12.0:
        bias_status = "OVERHEAT_OVERBOUGHT"  # 严重正乖离过热
    elif bias_ma20 < -12.0:
        bias_status = "DEEP_OVERSOLD"  # 严重负乖离超跌
    else:
        bias_status = "NORMAL_RANGE"

    weekly_summary_str = weekly_info.get("summary", "") if weekly_info else ""

    return {
        "macro_wyckoff_phase": macro_phase,
        "macro_phase_note": macro_note,
        "percentile_3y": f"{percentile_3y}%",
        "year_price_percentile": f"{year_percentile}%",
        "bias_ma500": f"{bias_ma500:+.2f}%" if bias_ma500 is not None else "N/A",
        "bias_ma250": f"{bias_ma250:+.2f}%" if bias_ma250 is not None else "N/A",
        "bias_ma120": f"{bias_ma120:+.2f}%" if bias_ma120 is not None else "N/A",
        "trading_range_60d": {
            "tr_high": tr_high,
            "tr_low": tr_low,
            "tr_position": f"{tr_position_pct}%",
            "tr_location": tr_location,
        },
        "micro_signals": {
            "volume_dry_up": volume_dry_up,
            "volume_expansion": volume_expansion,
            "vol_ratio_to_ma20": vol_ratio_to_ma20,
            "spring_detected": spring_detected,
            "upthrust_detected": upthrust_detected,
            "absorption_detected": absorption_detected,
            "bias_status": bias_status,
        },
        "summary": (
            f"宏观阶段: {macro_phase} (3年分位: {percentile_3y}%, 1年分位: {year_percentile}%, 年线乖离: {bias_ma250 if bias_ma250 is not None else 'N/A'}%, 两年线乖离: {bias_ma500 if bias_ma500 is not None else 'N/A'}%); "
            f"60日箱体: {tr_location} ({tr_position_pct}%位置); "
            f"量能: {'地量萎缩' if volume_dry_up else ('放量异动' if volume_expansion else '量能平稳')}({vol_ratio_to_ma20}x MA20); "
            f"形态: {'[Spring测试]' if spring_detected else ''}{'[UT假突破风险]' if upthrust_detected else ''}{'[筹码紧凑吸收]' if absorption_detected else ''}{'无异常形态' if not (spring_detected or upthrust_detected or absorption_detected) else ''}"
            + (f"; {weekly_summary_str}" if weekly_summary_str else "")
        ),
    }


def _window_return_pct(closes: List[float], window: int) -> Optional[float]:
    """计算 N 个交易日区间涨幅（收盘 vs window 个交易日前收盘），序列不足时退化为可得区间。

    与 `_sector_return` 采用完全一致的基期口径（`closes[-(w+1)]`），避免个股与板块
    同名字段相差一个交易日造成跨标的比较的系统性偏差。
    """
    n = len(closes)
    w = min(window, n - 1)
    if w <= 0:
        return None
    base = closes[-(w + 1)]
    return ((closes[-1] - base) / base * 100) if base > 0 else None


def fetch_stock_kline(symbol: str, count: int = 750, compact: bool = True) -> Dict[str, Any]:
    """
    获取 750 日 (约3年) 前复权日K线、全套均线矩阵 (MA20/50/120/250/500)、3年宏观时空坐标、内存周线共振与双层威科夫模型
    默认开启 compact=True 瘦身模式（保留3年宏观全景指标、周线共振趋势与最近30日微观K线），供 full/reduced/event 数据模式裁定
    """
    ts_code = normalize_symbol(symbol)
    cache_key = f"kline_{ts_code}_{count}_{compact}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    if not isinstance(count, int) or not 20 <= count <= 800:
        return {"error": "count 必须是 20 至 800 的整数", "data_status": "unavailable"}
    url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param={ts_code},day,,,{count},qfq"
    try:
        raw = http_get(url)
        data = json.loads(raw)
        root = data.get("data", {}).get(ts_code, {})
        # 仅接受明确返回的前复权序列，不能以未复权序列伪装通过硬门槛。
        bars_raw = root.get("qfqday") or []
        if not bars_raw:
            return {"error": f"未获取到前复权 K 线序列: {symbol}", "data_status": "unavailable"}

        # 格式化每根 K 线: [日期, 开盘, 收盘, 最高, 最低, 成交量]
        bars = []
        for row in bars_raw[-count:]:
            if len(row) >= 6:
                bars.append({
                    "date": str(row[0]),
                    "open": float(row[1]),
                    "close": float(row[2]),
                    "high": float(row[3]),
                    "low": float(row[4]),
                    "volume": float(row[5]),
                })

        valid_count = len(bars)
        if valid_count == 0:
            return {"error": "有效 K 线数量为 0"}

        closes = [b["close"] for b in bars]
        highs = [b["high"] for b in bars]
        lows = [b["low"] for b in bars]

        # 计算全周期均线矩阵: MA20 / MA50 / MA120 (半年线) / MA250 (年线) / MA500 (两年线)
        # 除数必须取 min(窗口, valid_count)：有效K线不足满窗口时用满窗口值作除数会系统性低估均线。
        ma20 = sum(closes[-20:]) / min(20, valid_count) if valid_count >= 5 else closes[-1]
        ma50 = sum(closes[-50:]) / min(50, valid_count) if valid_count >= 10 else closes[-1]
        ma120 = round(sum(closes[-120:]) / min(120, valid_count), 2) if valid_count >= 100 else None
        ma250 = round(sum(closes[-250:]) / min(250, valid_count), 2) if valid_count >= 200 else None
        ma500 = round(sum(closes[-500:]) / min(500, valid_count), 2) if valid_count >= 400 else None

        latest_close = closes[-1]
        bias_ma20 = (latest_close - ma20) / ma20 * 100 if ma20 else 0.0
        bias_ma50 = (latest_close - ma50) / ma50 * 100 if ma50 else 0.0

        # 计算 ATR(14) 真实波幅
        trs = []
        for i in range(1, valid_count):
            h = highs[i]
            l = lows[i]
            prev_c = closes[i - 1]
            tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
            trs.append(tr)
        atr14 = sum(trs[-14:]) / min(14, len(trs)) if trs else (highs[-1] - lows[-1])

        # 3年历史高低区间 (750根日线) 与 1年高低区间 (250根)
        high_3y = max(highs[-min(750, valid_count):])
        low_3y = min(lows[-min(750, valid_count):])
        high_year = max(highs[-min(250, valid_count):])
        low_year = min(lows[-min(250, valid_count):])

        # 内存无损聚合周线多周期共振体系
        weekly_analysis = aggregate_daily_to_weekly(bars)

        # 量能结构: 20日量比与120日量能分位 (盘中时当日成交量为未完成值)
        volumes = [b["volume"] for b in bars]
        latest_vol = volumes[-1]
        vol_20_mean = sum(volumes[-20:]) / min(20, valid_count) if valid_count >= 5 else latest_vol
        volume_ratio_20d = round(latest_vol / vol_20_mean, 2) if vol_20_mean and vol_20_mean > 0 else None
        vol_window = volumes[-min(120, valid_count):]
        if latest_vol and latest_vol > 0 and vol_window:
            volume_percentile_120d = round(sum(1 for v in vol_window if v <= latest_vol) / len(vol_window) * 100.0, 1)
        else:
            volume_percentile_120d = None

        # 预计算三层威科夫宏观与微观信号
        wyckoff_signals = compute_wyckoff_signals(
            bars, ma20, ma50, ma120, ma250, ma500, atr14, latest_close, bias_ma20,
            high_year, low_year, high_3y, low_3y, weekly_analysis
        )

        ret_5d = _window_return_pct(closes, 5)
        ret_20d = _window_return_pct(closes, 20)
        res = {
            "source": "P3_Tencent_QFQ_KLine",
            "data_status": "ok",
            "adjustment": "qfq",
            "symbol": symbol,
            "ts_code": ts_code,
            "valid_bars": valid_count,
            "hard_gate_passed": valid_count >= 120,
            "compact_mode": compact,
            "latest_date": bars[-1]["date"],
            "latest_close": latest_close,
            "ma20": round(ma20, 2),
            "ma50": round(ma50, 2),
            "ma120_half_year": ma120,
            "ma250_year_line": ma250,
            "ma500_2year_line": ma500,
            "bias_ma20": f"{bias_ma20:+.2f}%",
            "bias_ma50": f"{bias_ma50:+.2f}%",
            "bias_ma250_year": wyckoff_signals["bias_ma250"],
            "bias_ma500_2year": wyckoff_signals["bias_ma500"],
            "atr14": round(atr14, 2),
            "atr14_pct": f"{(atr14 / latest_close * 100):.2f}%",
            "high_120": max(highs[-min(120, valid_count):]),
            "low_120": min(lows[-min(120, valid_count):]),
            "high_year": high_year,
            "low_year": low_year,
            "high_3y": high_3y,
            "low_3y": low_3y,
            "percentile_3y": wyckoff_signals["percentile_3y"],
            "recent_5d_return": f"{ret_5d:+.2f}%" if ret_5d is not None else "N/A",
            "recent_20d_return": f"{ret_20d:+.2f}%" if ret_20d is not None else "N/A",
            "volume_ratio_20d": volume_ratio_20d,
            "volume_percentile_120d": volume_percentile_120d,
            "weekly_timeframe": weekly_analysis,
            "wyckoff_multi_timeframe": wyckoff_signals,
            "bars_summary": f"已检验 {valid_count} 根前复权日K线 (覆盖3年宏观时空，含MA120/MA250/MA500均线矩阵及周线共振)，可供数据模式裁定" + (" [精简视图：附最近30日K线]" if compact else " [完整视图：附全量K线]"),
        }

        # Token 瘦身模式：精简模式下返回最近 30 根 K 线 (约6周，完整展现局部 TR 结构)
        if compact:
            res["recent_30_bars"] = bars[-min(30, valid_count):]
        else:
            res["bars"] = bars

        set_cached(cache_key, res, ttl=CACHE_TTL_SECONDS * 2)
        return res
    except Exception as exc:
        return {"error": f"获取或解析前复权日K线出错: {type(exc).__name__}", "data_status": "unavailable"}


EM_UT = "7eea3edcaed734bea9cbfc24409ed989"
EM_DPT = "wz.ztzt"


def fetch_em_index_daily(secid: str, n: int) -> List[Dict[str, Any]]:
    """
    拉取东财指数日K序列 (含成交额，用于历史交易日的指数涨跌幅与两市成交额回补)
    fields2 顺序: f51日期, f52开, f53收, f54高, f55低, f56量, f57成交额(元)
    """
    url = (
        "/api/qt/stock/kline/get?secid=" + secid
        + f"&klt=101&fqt=0&lmt={n}&end=20500101"
        + "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61"
    )
    raw = em_kline_get(url, timeout=5)
    klines = (json.loads(raw).get("data") or {}).get("klines") or []
    out = []
    for line in klines[-n:]:
        parts = line.split(",")
        if len(parts) >= 7:
            out.append({
                "date": parts[0],
                "close": safe_float(parts[2], 0.0),
                "amount_yuan": safe_float(parts[6], 0.0),
            })
    return out


def fetch_market_sentiment(date_str: Optional[str] = None) -> Dict[str, Any]:
    """
    获取全市场情绪与量能总定调 (涨停数、炸板数、精确全市场炸板率、两市总成交额)
    直供 daily-review L1 情绪引擎与 market-prediction E4 量价簇
    历史日期的指数涨跌幅与成交额取自指数日K，不再混入实时快照
    """
    norm_date = normalize_date_str(date_str) if date_str else None
    if date_str and not norm_date:
        return {"error": "date_str 必须为 YYYYMMDD 或 YYYY-MM-DD", "data_status": "unavailable"}
    compact_date = norm_date.replace("-", "") if norm_date else datetime.now().strftime("%Y%m%d")
    is_today = compact_date == datetime.now().strftime("%Y%m%d")

    cache_key = f"sentiment_{compact_date}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    # 1. 抓取东方财富公开打板专题池 (免密 CDN)
    zt_count = 0
    zb_count = 0
    dt_count = 0
    max_height = 0
    unavailable_sources: List[str] = []

    try:
        # 涨停池
        zt_url = f"https://push2ex.eastmoney.com/getTopicZTPool?ut={EM_UT}&dpt={EM_DPT}&Pageindex=0&pagesize=500&sort=fbt:asc&date={compact_date}"
        zt_data = json.loads(http_get(zt_url, timeout=4)).get("data", {}).get("pool", [])
        zt_count = len(zt_data)
        if zt_data:
            max_height = max([int(x.get("lbc", 1)) for x in zt_data])
    except Exception as exc:
        unavailable_sources = [f"涨停池: {type(exc).__name__}"]

    try:
        # 炸板池
        zb_url = f"https://push2ex.eastmoney.com/getTopicZBPool?ut={EM_UT}&dpt={EM_DPT}&Pageindex=0&pagesize=500&sort=fbt:asc&date={compact_date}"
        zb_data = json.loads(http_get(zb_url, timeout=4)).get("data", {}).get("pool", [])
        zb_count = len(zb_data)
    except Exception as exc:
        unavailable_sources.append(f"炸板池: {type(exc).__name__}")

    try:
        # 跌停池
        dt_url = f"https://push2ex.eastmoney.com/getTopicDTPool?ut={EM_UT}&dpt={EM_DPT}&Pageindex=0&pagesize=500&sort=fund:asc&date={compact_date}"
        dt_data = json.loads(http_get(dt_url, timeout=4)).get("data", {}).get("pool", [])
        dt_count = len(dt_data)
    except Exception as exc:
        unavailable_sources.append(f"跌停池: {type(exc).__name__}")

    # 2. 指数涨跌幅与两市成交额: 当日用腾讯实时快照, 历史日期用东财指数日K回补 (不混用实时数据)
    sh_amount = 0.0
    sz_amount = 0.0
    sh_change = "0.00%"
    if is_today:
        try:
            idx_url = "https://qt.gtimg.cn/q=s_sh000001,s_sz399001,s_sz399006"
            idx_raw = http_get(idx_url)
            lines = [line for line in idx_raw.split(";") if line.strip()]
            for line in lines:
                if "s_sh000001" in line:
                    p = line.split("~")
                    sh_change_raw = p[5].strip('\\"')
                    sh_change = f"{float(sh_change_raw):+.2f}%"
                    sh_amount = float(p[7].strip('\\\"')) / 10000.0  # 成交额(万元) -> 亿元
                elif "s_sz399001" in line:
                    p = line.split("~")
                    sz_amount = float(p[7].strip('\\\"')) / 10000.0  # 成交额(万元) -> 亿元
        except Exception as exc:
            unavailable_sources.append(f"指数成交额: {type(exc).__name__}")
    else:
        lookback = 30  # 容忍长假后的历史回看窗口
        sh_close: Optional[float] = None
        sh_prev_close: Optional[float] = None
        date_found = False

        # 指数涨跌幅主源: 腾讯指数日K (独立通道, 限流概率低); 东财日K为备源
        try:
            sh_bars = fetch_index_daily_bars(INDEX_ALIASES["SHCI"][0], lookback)
            for i, bar in enumerate(sh_bars):
                if bar["date"] == norm_date:
                    date_found = True
                    if i > 0 and sh_bars[i - 1]["close"] > 0:
                        sh_prev_close = sh_bars[i - 1]["close"]
                        sh_close = bar["close"]
                    break
        except Exception:
            pass

        # 东财指数日K: 兜底涨跌幅, 且是历史成交额的唯一来源 (腾讯指数日K无成交额字段)
        em_sh_rows: List[Dict[str, Any]] = []
        em_ok = True
        try:
            em_sh_rows = fetch_em_index_daily("1.000001", lookback)
            if not date_found:
                for i, r in enumerate(em_sh_rows):
                    if r["date"] == norm_date:
                        date_found = True
                        if i > 0 and em_sh_rows[i - 1]["close"] > 0:
                            sh_prev_close = em_sh_rows[i - 1]["close"]
                            sh_close = r["close"]
                        break
        except Exception:
            em_ok = False

        if not date_found:
            return {
                "source": "P3_Public_Financial_Gateways",
                "data_status": "unavailable",
                "date": compact_date,
                "error": f"{norm_date} 非交易日或指数日K未覆盖该日期",
            }
        if sh_close is not None and sh_prev_close:
            sh_change = f"{((sh_close - sh_prev_close) / sh_prev_close * 100):+.2f}%"

        # 历史两市成交额: 沪市取上证指数、深市用深证综指 (覆盖全部深市股票) 的成交额口径
        if not em_ok:
            unavailable_sources.append("历史成交额: 东财指数日K不可用")
        else:
            sh_amount_row = next((r for r in em_sh_rows if r["date"] == norm_date), None)
            if sh_amount_row:
                sh_amount = sh_amount_row["amount_yuan"] / 100000000.0
            else:
                unavailable_sources.append("沪市历史成交额: 指数日K未覆盖该日期")
            try:
                sz_rows = fetch_em_index_daily("0.399106", lookback)
                sz_row = next((r for r in sz_rows if r["date"] == norm_date), None)
                if sz_row:
                    sz_amount = sz_row["amount_yuan"] / 100000000.0
                else:
                    unavailable_sources.append("深市历史成交额: 深证综指未覆盖该日期")
            except Exception as exc:
                unavailable_sources.append(f"深市历史成交额: {type(exc).__name__}")

    if unavailable_sources:
        return {
            "source": "P3_Public_Financial_Gateways",
            "data_status": "partial",
            "date": compact_date,
            "unavailable_sources": unavailable_sources,
            "message": "部分上游数据不可用，不能据此计算市场情绪结论。",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

    total_turnover = sh_amount + sz_amount
    total_touch = zt_count + zb_count
    break_rate = (zb_count / total_touch * 100) if total_touch > 0 else 0.0

    res = {
        "source": "P3_Public_Financial_Gateways",
        "data_status": "ok",
        "date": compact_date,
        "sh_index_change": sh_change,
        "total_turnover_billion": round(total_turnover, 2),
        "zt_count": zt_count,
        "zb_count": zb_count,
        "dt_count": dt_count,
        "exact_break_rate": f"{break_rate:.2f}%",
        "max_ladder_height": f"{max_height} 连板",
        "market_broad_status": "良性分歧" if break_rate < 30 else ("高位退潮" if break_rate > 45 else "震荡博弈"),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    set_cached(cache_key, res, ttl=CACHE_TTL_SECONDS if is_today else HISTORICAL_CACHE_TTL_SECONDS)
    return res


def fetch_limit_up_ladder(date_str: Optional[str] = None) -> Dict[str, Any]:
    """获取 A 股连板天梯矩阵 (各板高度代表票与晋级梯队)"""
    norm_date = normalize_date_str(date_str) if date_str else None
    if date_str and not norm_date:
        return {"error": "date_str 必须为 YYYYMMDD 或 YYYY-MM-DD", "data_status": "unavailable"}
    compact_date = norm_date.replace("-", "") if norm_date else datetime.now().strftime("%Y%m%d")
    is_today = compact_date == datetime.now().strftime("%Y%m%d")

    cache_key = f"ladder_{compact_date}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    url = f"https://push2ex.eastmoney.com/getTopicZTPool?ut={EM_UT}&dpt={EM_DPT}&Pageindex=0&pagesize=500&sort=fbt:asc&date={compact_date}"
    try:
        data = json.loads(http_get(url, timeout=4)).get("data", {}).get("pool", [])

        ladder: Dict[int, List[Dict[str, Any]]] = {}
        for item in data:
            height = int(item.get("lbc", 1))
            ladder.setdefault(height, []).append({
                "code": item.get("c"),
                "name": item.get("n"),
                "industry": item.get("hybk", "其他"),
                "first_time": item.get("fbt"),
                "last_time": item.get("lbt"),
                "fund_million": round(float(item.get("fund", 0)) / 10000.0, 2),
            })

        summary = []
        for h in sorted(ladder.keys(), reverse=True):
            stocks = ladder[h]
            all_leader_strs = [f"{s['name']}({s['code']})" for s in stocks]
            ind_counts: Dict[str, int] = {}
            for s in stocks:
                ind = s.get("industry", "其他")
                ind_counts[ind] = ind_counts.get(ind, 0) + 1
            top_industries = [f"{k}({v}家)" for k, v in sorted(ind_counts.items(), key=lambda x: x[1], reverse=True)[:5]]

            summary.append({
                "height": f"{h} 连板",
                "count": len(stocks),
                "leaders": all_leader_strs if (h > 1 or len(stocks) <= 12) else all_leader_strs[:10],
                "all_leaders": all_leader_strs,
                "industry_distribution": top_industries,
            })

        res = {
            "source": "P3_Eastmoney_LimitUp_Ladder",
            "data_status": "ok",
            "date": compact_date,
            "total_limit_up": len(data),
            "max_height": max(ladder.keys()) if ladder else 0,
            "ladder_distribution": summary,
        }
        set_cached(cache_key, res, ttl=CACHE_TTL_SECONDS if is_today else HISTORICAL_CACHE_TTL_SECONDS)
        return res
    except Exception as e:
        return {"error": f"获取连板天梯失败: {str(e)}"}


def fetch_topic_pool(pool_path: str, compact_date: str, sort_field: str) -> List[Dict[str, Any]]:
    """东财涨停/炸板/跌停池通用拉取 (push2ex, 支持历史 date 回补)"""
    url = (f"https://push2ex.eastmoney.com/{pool_path}?ut={EM_UT}&dpt={EM_DPT}"
           f"&Pageindex=0&pagesize=500&sort={sort_field}&date={compact_date}")
    return json.loads(http_get(url, timeout=4)).get("data", {}).get("pool", []) or []


PUSH2_LIST_HOSTS = [
    "push2.eastmoney.com",
    "23.push2.eastmoney.com",
    "48.push2.eastmoney.com",
    "push2delay.eastmoney.com",
]

EM_KLINE_HOSTS = [
    "push2his.eastmoney.com",
    "23.push2his.eastmoney.com",
    "48.push2his.eastmoney.com",
]


def em_kline_get(path: str, timeout: int = 5) -> str:
    """push2his 家族K线接口抓取; 主域被限流时自动切换镜像域名 (与板块表同一边缘, 同命运)"""
    last_exc: Optional[Exception] = None
    for host in EM_KLINE_HOSTS:
        try:
            return http_get(f"https://{host}{path}", timeout=timeout)
        except Exception as exc:
            last_exc = exc
    raise last_exc


EM_CLIST_NEGATIVE_TTL_SECONDS = 60


def fetch_industry_board_rows(fields: str, fid: str = "f3", max_pages: int = 8) -> List[Dict[str, Any]]:
    """
    东财行业板块全量行 (m:90+t:2), 跨分页聚合并按 f12 去重.
    clist 单页上限实测 100 行且东财行业板块 total 已达 ~496, 不翻页则成员表
    按当日涨跌幅截断漂移 (约 80% 板块随机缺席); 主域被限流时自动切换镜像域名.
    响应无 total 视为单页数据源 (兼容测试桩); 已知 total 但未取满视为该主机失败.
    主机族整体失败进入 60s 负缓存: THS 兜底曾逐名重试酿成 42.9s/135 次调用的解析风暴.
    """
    if get_cached("em_clist_failed"):
        raise ConnectionError("东财 clist 网关近期整体失败 (60s 负缓存)")
    last_exc: Optional[Exception] = None
    for host in PUSH2_LIST_HOSTS:
        try:
            rows: List[Dict[str, Any]] = []
            total: Optional[int] = None
            for pn in range(1, max_pages + 1):
                url = (f"https://{host}/api/qt/clist/get?pn={pn}&pz=100&po=1&np=1"
                       f"&fltt=2&invt=2&fid={fid}&fs=m:90+t:2+f:!50&fields={fields}")
                data = json.loads(http_get(url, timeout=5)).get("data") or {}
                if isinstance(data.get("total"), int):
                    total = data["total"]
                page_rows = data.get("diff") or []
                rows.extend(page_rows)
                if not page_rows or len(page_rows) < 100:
                    break
                if total is None:
                    break
                if len(rows) >= total:
                    break
            if rows and (total is None or len(rows) >= total):
                unique: Dict[str, Dict[str, Any]] = {}
                for r in rows:
                    key = str(r.get("f12", ""))
                    if key:
                        unique.setdefault(key, r)
                return list(unique.values())
        except Exception as exc:
            last_exc = exc
    set_cached("em_clist_failed", True, ttl=EM_CLIST_NEGATIVE_TTL_SECONDS)
    if last_exc:
        raise last_exc
    return []


def fetch_industry_board_list() -> List[Dict[str, str]]:
    """东财全量行业板块表 (代码+名称, 日级缓存); 兼作 hybk 缩写前缀歧义判定基准"""
    cached = get_cached("industry_board_list")
    if cached:
        return cached
    rows = fetch_industry_board_rows("f12,f14")
    boards = [{"code": str(r.get("f12", "")), "name": str(r.get("f14", "")).strip()}
              for r in rows if str(r.get("f12", "")).startswith("BK")]
    if not boards:
        raise ValueError("行业板块表为空")
    set_cached("industry_board_list", boards, ttl=86400)
    return boards


def industry_hybk_matches(hybk: str, board_name: str) -> bool:
    """涨停/炸板池 hybk 为 <=4 字行业缩写 (如"农产品加工"->"农产品加"), 全称相等或缩写为全称前缀才算同板块"""
    short = (hybk or "").strip()
    full = (board_name or "").strip()
    if not short or not full:
        return False
    return full == short or full.startswith(short)


def _industry_board_rejection(error: str, boards: Optional[List[Dict[str, str]]]) -> Dict[str, Any]:
    """拒绝无效板块时回传全量可用行业板块清单, 让调用方一次改对传参而非逐个试错"""
    payload = {
        "error": error,
        "data_status": "unavailable",
        "hint": "仅接受东财行业板块 (t:2, 含一/二/三级行业, 名称可能带Ⅱ/Ⅲ后缀); 概念/题材板块无 hybk 归属, 不支持",
    }
    if boards:
        payload["available_industry_boards"] = boards
    return payload


def fetch_sector_limit_quality(sector: str, date_str: Optional[str] = None) -> Dict[str, Any]:
    """
    板块级触板/炸板结构与板块炸板率 (直供 Q=(1-板块炸板率)×100 的确定性输入)
    涨停池/炸板池 hybk 为 <=4 字行业缩写, 此处按前缀规则匹配并对全板块表做歧义校验,
    杜绝"按板块全称精确匹配漏票"导致的板块炸板率失真; 触板 <3 家时 Q 记 null (小样本不稳定)
    """
    if not isinstance(sector, str) or not sector.strip():
        return {"error": "sector 必须是非空字符串", "data_status": "unavailable"}
    norm_date = normalize_date_str(date_str) if date_str else None
    if date_str and not norm_date:
        return {"error": "date_str 必须为 YYYYMMDD 或 YYYY-MM-DD", "data_status": "unavailable"}
    compact_date = norm_date.replace("-", "") if norm_date else datetime.now().strftime("%Y%m%d")
    is_today = compact_date == datetime.now().strftime("%Y%m%d")

    clean = sector.strip()
    upper = clean.upper().replace("90.", "")
    sector_code = upper if upper.startswith("BK") and upper[2:].isdigit() else resolve_sector_code(clean)
    try:
        boards = fetch_industry_board_list()
    except Exception as exc:
        return {"error": f"行业板块表不可用: {type(exc).__name__}", "data_status": "unavailable"}
    if not sector_code:
        return _industry_board_rejection(f"无法解析板块: {clean} (仅支持行业板块中文名或 BK 代码)", boards)
    target = next((b for b in boards if b["code"] == sector_code or b["name"] == clean), None)
    if not target:
        return _industry_board_rejection(
            f"{sector_code} 不在东财行业板块表内 (仅支持行业板块, 概念板块无 hybk 归属)", boards)
    sector_code = target["code"]

    cache_key = f"sector_limit_quality_{sector_code}_{compact_date}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    unavailable_sources: List[str] = []
    try:
        zt_pool = fetch_topic_pool("getTopicZTPool", compact_date, "fbt:asc")
    except Exception:
        zt_pool = []
        unavailable_sources.append(f"涨停池@{compact_date}")
    try:
        zb_pool = fetch_topic_pool("getTopicZBPool", compact_date, "fbt:asc")
    except Exception:
        zb_pool = []
        unavailable_sources.append(f"炸板池@{compact_date}")
    if not zt_pool and not zb_pool:
        res = {"error": f"{compact_date} 涨停池与炸板池均为空 (可能为非交易日或数据源未覆盖)",
               "data_status": "unavailable"}
        return res

    def attribute(pool: List[Dict[str, Any]], extra_fields) -> Tuple[List, List]:
        """按 hybk 归属目标板块: 精确同名唯一归属; 否则前缀匹配, 与多个板块前缀冲突的缩写剔除并返回歧义清单"""
        matched, ambiguous = [], []
        for item in pool:
            hybk = str(item.get("hybk", "") or "").strip()
            exact = next((b for b in boards if b["name"] == hybk), None)
            entry = {"code": item.get("c"), "name": item.get("n"), "industry_raw": hybk or "N/A"}
            entry.update(extra_fields(item))
            if exact is not None:
                if exact["code"] == target["code"]:
                    matched.append(entry)
                continue
            if not industry_hybk_matches(hybk, target["name"]):
                continue
            collisions = [b["name"] for b in boards
                          if b["code"] != target["code"] and industry_hybk_matches(hybk, b["name"])]
            if collisions:
                entry["ambiguous_with"] = collisions
                ambiguous.append(entry)
            else:
                matched.append(entry)
        return matched, ambiguous

    sealed, ambiguous_zt = attribute(zt_pool, lambda it: {"lbc": int(it.get("lbc", 1) or 1), "first_time": it.get("fbt")})
    broken, ambiguous_zb = attribute(zb_pool, lambda it: {"break_count": int(it.get("zbc", 1) or 1)})

    sealed_count, broken_count = len(sealed), len(broken)
    touched = sealed_count + broken_count
    rate = round(broken_count / touched * 100.0, 2) if touched else 0.0
    q_value = round((1 - broken_count / touched) * 100.0, 1) if touched >= 3 else None
    if touched >= 3:
        q_note = "Q=(1-板块炸板率)×100; 供评分层直接使用"
    elif touched > 0:
        q_note = "触板不足 3 家, Q 记 null (小样本炸板率不稳定), 评分层对可得权重归一化, 不得借用全市场炸板率"
    else:
        q_note = "本板块当日无触板个股, Q 记 null"

    ambiguous = ambiguous_zt + ambiguous_zb
    res = {
        "source": "P3_Eastmoney_Sector_Limit_Quality",
        "data_status": "partial" if unavailable_sources else "ok",
        "sector": target["name"],
        "sector_code": target["code"],
        "date": compact_date,
        "sealed_count": sealed_count,
        "broken_count": broken_count,
        "touched_count": touched,
        "sector_break_rate": f"{rate:.2f}%",
        "seal_quality_q": q_value,
        "q_note": q_note,
        "industry_match_rule": "hybk 与板块全称精确相等时唯一归属; 否则 hybk(<=4字缩写)按前缀匹配全称, 与多个板块前缀冲突的缩写剔除并披露",
        "limit_up_stocks": sealed,
        "broken_stocks": broken,
    }
    if ambiguous:
        res["ambiguous_industry_stocks"] = ambiguous
    if unavailable_sources:
        res["unavailable_sources"] = unavailable_sources
    set_cached(cache_key, res, ttl=CACHE_TTL_SECONDS if is_today else HISTORICAL_CACHE_TTL_SECONDS)
    return res


def fetch_market_breadth(days: int = 5) -> Dict[str, Any]:
    """
    获取全市场广度 N 个交易日序列:
    - 最新交易日: 东财涨跌分布快照给出精确的上涨/下跌/平盘家数与红盘率 (快照仅支持最新交易日)
    - 历史交易日: 官方公开网关不提供全市场涨跌家数, 以涨停/炸板/跌停池与沪指逐日涨跌幅替代,
      并通过 breadth_precision 字段显式标注精度, 绝不估算
    直供 sector-rotation 全窗口市场广度温度计与情绪退潮识别
    """
    if not isinstance(days, int) or not 2 <= days <= 10:
        return {"error": "days 必须是 2 至 10 的整数", "data_status": "unavailable"}

    cached = get_cached(f"breadth_{days}")
    if cached:
        return cached

    # 1. 交易日序列以沪指日K为准 (不自行维护交易日历)
    try:
        sh_bars = fetch_index_daily_bars(INDEX_ALIASES["SHCI"][0], days)
    except Exception as exc:
        return {"error": f"交易日序列(沪指日K)不可用: {type(exc).__name__}", "data_status": "unavailable"}
    if len(sh_bars) < 2:
        return {"error": "沪指日K序列不足，无法构建交易日窗口", "data_status": "unavailable"}

    unavailable_sources: List[str] = []

    # 2. 最新交易日的精确涨跌家数快照
    exact = None
    exact_date = None
    try:
        raw = http_get(f"https://push2ex.eastmoney.com/getTopicZDFenBu?ut={EM_UT}&dpt={EM_DPT}")
        data = json.loads(raw).get("data", {}) or {}
        qdate = str(data.get("qdate", ""))
        fenbu: Dict[str, int] = {}
        for item in data.get("fenbu", []) or []:
            if isinstance(item, dict):
                fenbu.update(item)
        up = sum(v for k, v in fenbu.items() if str(k).lstrip("-").isdigit() and int(k) > 0)
        down = sum(v for k, v in fenbu.items() if str(k).lstrip("-").isdigit() and int(k) < 0)
        flat = sum(v for k, v in fenbu.items() if str(k) == "0")
        total = up + down + flat
        if total > 0:
            bins_order = [
                ("-11", -11.0, -10.0), ("-10", -10.0, -9.0), ("-9", -9.0, -8.0), ("-8", -8.0, -7.0),
                ("-7", -7.0, -6.0), ("-6", -6.0, -5.0), ("-5", -5.0, -4.0), ("-4", -4.0, -3.0),
                ("-3", -3.0, -2.0), ("-2", -2.0, -1.0), ("-1", -1.0, 0.0), ("0", 0.0, 0.0),
                ("1", 0.0, 1.0), ("2", 1.0, 2.0), ("3", 2.0, 3.0), ("4", 3.0, 4.0),
                ("5", 4.0, 5.0), ("6", 5.0, 6.0), ("7", 6.0, 7.0), ("8", 7.0, 8.0),
                ("9", 8.0, 9.0), ("10", 9.0, 10.0), ("11", 10.0, 11.0)
            ]
            target = total / 2.0
            cum = 0
            median_val = 0.0
            for b_key, low, high in bins_order:
                cnt = fenbu.get(b_key, 0) or fenbu.get(int(b_key), 0)
                if not cnt:
                    continue
                if cum + cnt >= target:
                    if low == high:
                        median_val = low
                    else:
                        fraction = (target - cum) / cnt
                        median_val = round(low + fraction * (high - low), 2)
                    break
                cum += cnt

            exact = {
                "up_count": up, "down_count": down, "flat_count": flat,
                "total_stocks": total, "red_rate": round(up / total * 100.0, 2),
                "median_change_pct": f"{median_val:+.2f}%",
                "median_pct": median_val,
            }
            exact_date = f"{qdate[:4]}-{qdate[4:6]}-{qdate[6:8]}" if len(qdate) == 8 else None
    except Exception as exc:
        unavailable_sources.append(f"涨跌分布快照: {type(exc).__name__}")

    # 3. 逐交易日组装: 指数涨跌幅 + 情绪池 (东财池支持历史 date 回补)
    def pool_json(pool_path: str, d_compact: str, sort_field: str) -> List[Dict[str, Any]]:
        return fetch_topic_pool(pool_path, d_compact, sort_field)

    day_rows: List[Dict[str, Any]] = []
    for i in range(max(1, len(sh_bars) - days), len(sh_bars)):
        cur, prev = sh_bars[i], sh_bars[i - 1]
        d_dash = cur["date"]
        d_compact = d_dash.replace("-", "")
        row: Dict[str, Any] = {
            "date": d_dash,
            "sh_index_change": f"{((cur['close'] - prev['close']) / prev['close'] * 100):+.2f}%" if prev["close"] > 0 else "N/A",
            "breadth_precision": "limit_pools_only",
        }
        if exact and d_dash == exact_date:
            row.update({
                "up_count": exact["up_count"],
                "down_count": exact["down_count"],
                "flat_count": exact["flat_count"],
                "total_stocks": exact["total_stocks"],
                "red_rate": f"{exact['red_rate']:.2f}%",
                "median_change_pct": exact["median_change_pct"],
                "median_pct": exact["median_pct"],
                "breadth_precision": "exact",
            })
        try:
            zt_rows = pool_json("getTopicZTPool", d_compact, "fbt:asc")
            row["zt_count"] = len(zt_rows)
            row["max_ladder_height"] = max([int(x.get("lbc", 1) or 1) for x in zt_rows]) if zt_rows else 0
        except Exception:
            unavailable_sources.append(f"涨停池@{d_dash}")
        try:
            row["zb_count"] = len(pool_json("getTopicZBPool", d_compact, "fbt:asc"))
        except Exception:
            unavailable_sources.append(f"炸板池@{d_dash}")
        try:
            row["dt_count"] = len(pool_json("getTopicDTPool", d_compact, "fund:asc"))
        except Exception:
            unavailable_sources.append(f"跌停池@{d_dash}")
        day_rows.append(row)

    res = {
        "source": "P3_Public_Financial_Gateways",
        "data_status": "partial" if (unavailable_sources or exact is None) else "ok",
        "days_window": day_rows,
        "note": ("最新交易日为精确全市场涨跌家数口径 (breadth_precision=exact)；"
                 "历史交易日官方公开网关不提供全市场涨跌家数，以涨停/炸板/跌停池与沪指涨跌幅替代 "
                 "(breadth_precision=limit_pools_only)，不进行估算"),
    }
    if exact:
        res["latest_exact_snapshot"] = {"date": exact_date, **exact}
    if unavailable_sources:
        res["unavailable_sources"] = unavailable_sources
    set_cached(f"breadth_{days}", res)
    return res


def fetch_sector_fund_history(sector_code: str, days: int) -> List[Dict[str, Any]]:
    """
    获取单个行业板块的主力资金流日K历史 (东财 fflow daykline 网关, 带板块级缓存)
    每行字段序: 日期, 主力净额(元), 小单, 中单, 大单, 超大单, 各占比..., 收盘, 涨跌幅...
    """
    cache_key = f"fflow_{sector_code}_{days}"
    cached = get_cached(cache_key)
    if cached:
        return cached
    url = (
        "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get"
        f"?lmt={days}&klt=101&secid=90.{sector_code}&secid2=90.{sector_code}"
        "&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65"
    )
    raw = http_get(url, timeout=4)
    klines = (json.loads(raw).get("data") or {}).get("klines") or []
    hist = []
    for line in klines[-days:]:
        parts = line.split(",")
        if len(parts) >= 13:
            hist.append({
                "date": parts[0],
                "main_net_inflow_billion": round(safe_float(parts[1], 0.0) / 100000000.0, 2),
                "change_pct": f"{safe_float(parts[12], 0.0):+.2f}%",
            })
    if not hist:
        raise ValueError("资金流历史为空")
    set_cached(cache_key, hist, ttl=ttl_for_history(hist[-1]["date"]))
    return hist


def fund_flow_trend_label(hist: List[Dict[str, Any]]) -> str:
    """根据逐日主力净额符号序列给出资金趋势定性"""
    if not hist:
        return "N/A"
    values = [h["main_net_inflow_billion"] for h in hist]
    if all(v == 0 for v in values):
        return "零净流入"  # 全零序列按符号判定会被误标为"连续净流出"
    signs = [1 if v > 0 else -1 for v in values]
    if all(s > 0 for s in signs):
        return "连续净流入"
    if all(s < 0 for s in signs):
        return "连续净流出"
    return "净流出转净流入" if signs[-1] > 0 else "净流入转净流出"


# 代码均经东财 suggest 网关 (MktNum=90 行业) 与 clist 全量表交叉核实 (2026-10 复核)。
# 旧表大量串号 (如 电池→一般零售/煤炭→工程建设/通信设备→银行), 已全部修正;
# 无法核实的别名 (消费电子/人工智能/算力/稀土 等概念词) 一律删除, 交由动态解析,
# 解析失败时错误信息会回传 available_industry_boards 全量清单。
STATIC_SECTOR_MAP: Dict[str, str] = {
    "半导体": "BK1036", "芯片": "BK1036", "集成电路": "BK1036",
    "半导体设备": "BK1326",
    "通信设备": "BK0448", "通信": "BK0448",
    "电子元件": "BK0459", "元件": "BK0459", "PCB": "BK0459", "覆铜板": "BK0459",
    "光学光电子": "BK1038", "显示面板": "BK1038", "LED": "BK1038",
    "计算机设备": "BK0735",
    "互联网服务": "BK0447",
    "游戏": "BK1046", "网络游戏": "BK1046",
    "信创": "BK1104",
    "光伏设备": "BK1031", "光伏": "BK1031", "太阳能": "BK1031",
    "风电设备": "BK1032", "风电": "BK1032", "海上风电": "BK1032",
    "电池": "BK1033", "锂电池": "BK1033",
    "电网设备": "BK0457", "特高压": "BK0457", "智能电网": "BK0457",
    "电力行业": "BK0428", "电力": "BK0428",
    "证券": "BK0473", "券商": "BK0473", "证券行业": "BK0473",
    "银行": "BK0475", "银行业": "BK0475",
    "保险": "BK0474", "保险业": "BK0474",
    "多元金融": "BK0738", "信托": "BK0738", "期货": "BK0738",
    "汽车整车": "BK1029", "整车": "BK1029",
    "汽车零部件": "BK0481", "汽配": "BK0481",
    "通用设备": "BK0545",
    "专用设备": "BK0910",
    "化学制药": "BK0465",
    "创新药": "BK1106",
    "中药": "BK1040", "中药Ⅱ": "BK1040",
    "生物制品": "BK1044",
    "医疗器械": "BK1041",
    "医疗服务": "BK0727",
    "贵金属": "BK0732", "黄金": "BK0732", "白银": "BK0732",
    "钢铁行业": "BK0479", "钢铁": "BK0479",
    "煤炭行业": "BK0437", "煤炭": "BK0437",
    "石油行业": "BK0496", "石油": "BK0496",
    "化学制品": "BK0538",
    "白酒": "BK0896",
    "商业百货": "BK0482",
    "旅游酒店": "BK0485", "旅游": "BK0485", "酒店餐饮": "BK0485",
    "文化传媒": "BK0486", "传媒": "BK0486",
    "房地产开发": "BK0488", "房地产": "BK0488", "地产": "BK0488",
    "航天航空": "BK0480",
    "军工": "BK0490", "国防军工": "BK0490",
    "军工电子": "BK1233",
    "航运港口": "BK0450", "航运": "BK0450", "港口": "BK0450",
    "环保行业": "BK0728", "环保": "BK0728",
    "玻璃玻纤": "BK0546", "玻璃": "BK0546",
    "农牧饲渔": "BK0433",
    "养殖业": "BK1259",
    "建筑装饰": "BK1209",
    "工程建设": "BK0425",
    "物流": "BK0422",
    "教育": "BK0740",
}

# 核心行业权重股等权篮子映射 (当东财板块K线网关不可用时自动作为代理序列源)
# 键位与 STATIC_SECTOR_MAP 的核实代码保持一致 (2026-10 复核)
STATIC_SECTOR_BASKETS = {
    "BK1036": ["688981", "002371", "688256"],  # 半导体
    "BK0448": ["000063", "600941", "601728"],  # 通信设备
    "BK0459": ["002475", "300476", "002384"],  # 电子元件 / PCB
    "BK1031": ["601012", "300274", "688599"],  # 光伏设备
    "BK1033": ["300750", "300014", "002812"],  # 电池
    "BK0473": ["600030", "000776", "601688"],  # 证券
    "BK0896": ["600519", "000858", "000568"],  # 白酒
    "BK0475": ["600036", "601398", "601288"],  # 银行
    "BK0474": ["601318", "601628", "601601"],  # 保险
    "BK0488": ["000002", "600048", "001979"],  # 房地产
    "BK1029": ["002594", "601238", "600104"],  # 汽车整车
    "BK0490": ["600760", "600893", "000768"],  # 军工
    "BK0538": ["600309", "002493", "600426"],  # 化学制品
    "BK0437": ["601088", "601225", "600188"],  # 煤炭
    "BK0496": ["601857", "600028", "600938"],  # 石油
    "BK0465": ["600276", "000538", "600085"],  # 化学制药
    "BK0450": ["601919", "600018", "601872"],  # 航运港口
    "BK0735": ["002230", "300308", "600845"],  # 计算机设备 / 算力
}

# 同花顺 6 位行业板块代码字典 (881xxx)
# EM BK 键位经 2026-10 复核: 对不上东财行业板块表的串号键已剔除, 名称键保留
THS_SECTOR_MAP = {
    "半导体": "881121", "BK1036": "881121",
    "通信设备": "881129", "BK0448": "881129",
    "消费电子": "881124", "BK0459": "881124", "电子元件": "881124", "PCB": "881124",
    "计算机设备": "881115", "算力": "881115",
    "光学光电子": "881122",
    "证券": "881157", "BK0473": "881157", "券商": "881157",
    "银行": "881155", "BK0475": "881155",
    "保险": "881156", "BK0474": "881156",
    "多元金融": "881158",
    "汽车整车": "881125",
    "汽车零部件": "881126", "BK0481": "881126",
    "电池": "881146", "BK1033": "881146",
    "光伏设备": "881145", "BK1031": "881145",
    "风电设备": "881280", "BK1032": "881280",
    "白酒": "881133", "饮料制造": "881133", "食品饮料": "881133",
    "食品加工制造": "881134",
    "化学制药": "881140", "BK0465": "881140", "医药": "881140",
    "中药": "881141",
    "生物制品": "881142",
    "医疗器械": "881144",
    "医疗服务": "881175",
    "医药商业": "881143",
    "游戏": "881275",
    "文化传媒": "881164", "传媒": "881164",
    "影视院线": "881274",
    "房地产": "881153", "BK0488": "881153", "房地产开发": "881153",
    "建筑装饰": "881116",
    "建筑材料": "881115",
    "通用设备": "881117", "机器人": "881117",
    "专用设备": "881118",
    "自动化设备": "881171",
    "煤炭": "881105", "煤炭开采加工": "881105",
    "港口航运": "881148", "航运港口": "881148",
    "公路铁路运输": "881149",
    "电力": "881165",
    "环保设备": "881284", "环保": "881284",
    "基础化工": "881109", "化学制品": "881109",
    "钢铁": "881185",
    "有色金属": "881187", "工业金属": "881187",
    "贵金属": "881186", "黄金": "881186",
    "旅游及酒店": "881160",
    "互联网电商": "881177",
    "教育": "881178",
    "农产品加工": "881103",
    "养殖业": "881102",
    "种植业与林业": "881101",
    "家居用品": "881139",
    "服装家纺": "881136",
    "造纸": "881137",
    "小家电": "881173",
    "白色家电": "881131",
}


def resolve_ths_sector_code(sector: str, sector_code: Optional[str] = None) -> Optional[str]:
    """解析为同花顺 6 位行业代码 (881xxx)"""
    if sector_code and sector_code in THS_SECTOR_MAP:
        return THS_SECTOR_MAP[sector_code]
    clean = sector.strip()
    if clean in THS_SECTOR_MAP:
        return THS_SECTOR_MAP[clean]
    stripped = clean.rstrip("行业").rstrip("板块")
    if stripped in THS_SECTOR_MAP:
        return THS_SECTOR_MAP[stripped]
    for k, v in THS_SECTOR_MAP.items():
        if k in clean or clean in k:
            return v
    return None




def resolve_sector_code(keyword: str) -> Optional[str]:
    """解析板块名称或代码为东财行业板块代码 (BKxxxxxx)；
    优先级: 静态别名字典 → 全量板块表精确同名 → 联想网关(优先行业MktNum=90) → 全量板块表唯一子串模糊。
    精确同名先于联想: 联想首个命中可能是概念板块或子行业, 会静默解析到字面不同的板块。
    """
    clean = keyword.strip()
    upper = clean.upper().replace("90.", "")
    if upper.startswith("BK") and upper[2:].isdigit():
        return upper

    # 1. 优先查内置高可靠标准板块映射
    if clean in STATIC_SECTOR_MAP:
        return STATIC_SECTOR_MAP[clean]
    stripped = clean.rstrip("行业").rstrip("板块")
    if stripped in STATIC_SECTOR_MAP:
        return STATIC_SECTOR_MAP[stripped]

    cache_key = f"sector_lookup_{clean}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    def _remember(code: str) -> str:
        set_cached(cache_key, code, ttl=86400)
        return code

    # 2. 全量行业板块表精确同名 (日级缓存, 命中即字面一致)
    try:
        boards = fetch_industry_board_list()
        exact = next((b["code"] for b in boards if b["name"] == clean), None)
        if exact:
            return _remember(exact)
    except Exception:
        boards = None

    # 3. 东财建议网关联想 (轻量稳定; 行业板块 MktNum=90 优先于概念)
    try:
        suggest_url = f"https://searchapi.eastmoney.com/api/suggest/get?input={urllib.parse.quote(clean)}&type=14"
        sug_raw = http_get(suggest_url, timeout=3)
        sug_items = json.loads(sug_raw).get("QuotationCodeTable", {}).get("Data", []) or []
        bk_items = [x for x in sug_items
                    if x.get("Classify") == "BK" and str(x.get("Code", "")).startswith("BK")]
        pick = next((x for x in bk_items if x.get("MktNum") == "90"), None) or (bk_items[0] if bk_items else None)
        if pick:
            return _remember(str(pick["Code"]))
    except Exception:
        pass

    # 4. 兜底全量行业板块表唯一子串模糊 (多个命中视为歧义, 返回 None 由调用方报候选)
    if boards:
        fuzzy = [b for b in boards if clean in b["name"]]
        if len(fuzzy) == 1:
            return _remember(fuzzy[0]["code"])
    return None


def _sector_ma(closes: List[float], window: int) -> Optional[float]:
    return round(sum(closes[-window:]) / window, 2) if len(closes) >= window else None


def _sector_return(closes: List[float], window: int) -> str:
    n = len(closes)
    w = min(window, n - 1)  # 序列不足窗口时退化为可得区间
    base = closes[-(w + 1)]
    return f"{((closes[-1] - base) / base * 100):+.2f}%" if base > 0 else "N/A"


def fetch_sector_kline(sector: str, count: int = 130) -> Dict[str, Any]:
    """
    获取东财行业板块指数日K序列、均线体系、区间涨幅与资金证据
    主源为东财标准K线 (完整OHLCV+成交额, 支撑板块资金延续评分的成交额对比);
    主源不可用时自动兜底 fflow daykline (收盘序列+主力净额, 高低点为收盘价口径)
    直供 stock-analysis L4 行业基准、daily-review 资金延续 V 项与 L2 板块强度证据
    """
    if not isinstance(count, int) or not 20 <= count <= 250:
        return {"error": "count 必须是 20 至 250 的整数", "data_status": "unavailable"}
    sector_code = resolve_sector_code(sector)
    if not sector_code:
        err: Dict[str, Any] = {
            "error": f"无法解析板块: {sector} (仅支持东财行业板块中文名或 BK 代码; 板块代码可用 get_sector_fund_flow 查询)",
            "data_status": "unavailable",
        }
        # 名称可能命中多个板块 (如"电网"同时前缀匹配 电网设备/电网自动化设备), 给出候选让调用方改对, 不静默二选一
        try:
            boards = fetch_industry_board_list()
            candidates = [f"{b['name']}({b['code']})" for b in boards if sector.strip() and sector.strip() in b["name"]][:8]
            if candidates:
                err["sector_candidates"] = candidates
                err["error"] += f"；相关行业板块候选: {', '.join(candidates)}"
        except Exception:
            pass
        return err

    cache_key = f"sector_kline_{sector_code}_{count}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    failed_sources: List[str] = []

    # 主源: 东财标准K线 (完整 OHLCV + 成交额)
    try:
        kline_url = (
            "/api/qt/stock/kline/get"
            f"?secid=90.{sector_code}&klt=101&fqt=1&lmt={count}&end=20500101"
            "&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57"
        )
        data = (json.loads(em_kline_get(kline_url, timeout=5)).get("data") or {})
        klines = data.get("klines") or []
        rows = []
        for line in klines[-count:]:
            parts = line.split(",")
            if len(parts) >= 7:
                rows.append({
                    "date": parts[0],
                    "open": safe_float(parts[1], 0.0),
                    "close": safe_float(parts[2], 0.0),
                    "high": safe_float(parts[3], 0.0),
                    "low": safe_float(parts[4], 0.0),
                    "amount_billion": round(safe_float(parts[6], 0.0) / 100000000.0, 2),
                })
        closes = [r["close"] for r in rows]
        n = len(closes)
        if n >= 2 and closes[-1] > 0:
            amounts = [r["amount_billion"] for r in rows]
            prev_amount = amounts[-2] if n >= 2 else None
            res = {
                "source": "P3_Eastmoney_Sector_Kline",
                "data_status": "ok",
                "ohlc_source": True,
                "sector_code": sector_code,
                "sector_name": data.get("name", sector),
                "valid_bars": n,
                "latest_date": rows[-1]["date"],
                "latest_close": closes[-1],
                "latest_open": rows[-1]["open"],
                "latest_high": rows[-1]["high"],
                "latest_low": rows[-1]["low"],
                "latest_change_pct": _sector_return(closes, 1),
                "ma5": _sector_ma(closes, 5),
                "ma10": _sector_ma(closes, 10),
                "ma20": _sector_ma(closes, 20),
                "ma60": _sector_ma(closes, 60),
                "recent_5d_return": _sector_return(closes, 5),
                "recent_20d_return": _sector_return(closes, 20),
                "recent_60d_return": _sector_return(closes, 60),
                "high_20d": max(r["high"] for r in rows[-min(20, n):]),
                "low_20d": min(r["low"] for r in rows[-min(20, n):]),
                "high_60d": max(r["high"] for r in rows[-min(60, n):]),
                "low_60d": min(r["low"] for r in rows[-min(60, n):]),
                "latest_amount_billion": amounts[-1],
                "prev_amount_billion": prev_amount,
                "amount_ratio_1d": round(amounts[-1] / prev_amount, 2) if prev_amount and prev_amount > 0 else None,
                "avg_amount_5d_billion": round(sum(amounts[-min(5, n):]) / min(5, n), 2),
                "note": "完整OHLCV+成交额口径 (东财板块标准K线)；amount_ratio_1d 即板块资金延续评分 (Capital Continuity) 成交连续度 V 项的直接输入",
            }
            if n < count:
                res["data_status"] = "partial"
                res["note"] += f"；实际仅取得 {n} 根 (不足请求的 {count} 根)"
            set_cached(cache_key, res, ttl=ttl_for_history(rows[-1]["date"]))
            return res
        failed_sources.append("eastmoney_standard_kline(响应无有效K线)")
    except Exception as exc:
        failed_sources.append(f"eastmoney_standard_kline({type(exc).__name__})")

    # 备源 1: 同花顺板块原生日K网关 (完整 OHLCV + 真实成交额)
    ths_code = resolve_ths_sector_code(sector, sector_code)
    if ths_code:
        try:
            ths_url = f"https://d.10jqka.com.cn/v6/line/bk_{ths_code}/01/last.js"
            raw_ths = http_get(ths_url, timeout=4, encoding="gbk")
            if "(" in raw_ths and ")" in raw_ths:
                data_str = raw_ths[raw_ths.index("(") + 1 : raw_ths.rindex(")")]
                obj = json.loads(data_str)
                parts = [b for b in obj.get("data", "").split(";") if b]
                rows = []
                for p in parts[-count:]:
                    fields = p.split(",")
                    if len(fields) >= 7:
                        d = fields[0]
                        fmt_date = f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 else d
                        rows.append({
                            "date": fmt_date,
                            "open": safe_float(fields[1], 0.0),
                            "high": safe_float(fields[2], 0.0),
                            "low": safe_float(fields[3], 0.0),
                            "close": safe_float(fields[4], 0.0),
                            "amount_billion": round(safe_float(fields[6], 0.0) / 100000000.0, 2),
                        })
                closes = [r["close"] for r in rows]
                n = len(closes)
                if n >= 2 and closes[-1] > 0:
                    amounts = [r["amount_billion"] for r in rows]
                    prev_amount = amounts[-2] if n >= 2 else None
                    res = {
                        "source": "P3_THS_Sector_Kline",
                        "data_status": "ok",
                        "ohlc_source": True,
                        "sector_code": sector_code,
                        "ths_code": f"bk_{ths_code}",
                        "sector_name": obj.get("name") or sector,
                        "valid_bars": n,
                        "latest_date": rows[-1]["date"],
                        "latest_close": closes[-1],
                        "latest_open": rows[-1]["open"],
                        "latest_high": rows[-1]["high"],
                        "latest_low": rows[-1]["low"],
                        "latest_change_pct": _sector_return(closes, 1),
                        "ma5": _sector_ma(closes, 5),
                        "ma10": _sector_ma(closes, 10),
                        "ma20": _sector_ma(closes, 20),
                        "ma60": _sector_ma(closes, 60),
                        "recent_5d_return": _sector_return(closes, 5),
                        "recent_20d_return": _sector_return(closes, 20),
                        "recent_60d_return": _sector_return(closes, 60),
                        "high_20d": max(r["high"] for r in rows[-min(20, n):]),
                        "low_20d": min(r["low"] for r in rows[-min(20, n):]),
                        "high_60d": max(r["high"] for r in rows[-min(60, n):]),
                        "low_60d": min(r["low"] for r in rows[-min(60, n):]),
                        "latest_amount_billion": amounts[-1],
                        "prev_amount_billion": prev_amount,
                        "amount_ratio_1d": round(amounts[-1] / prev_amount, 2) if prev_amount and prev_amount > 0 else None,
                        "avg_amount_5d_billion": round(sum(amounts[-min(5, n):]) / min(5, n), 2),
                        "note": "东财标准K线不可用，已自动切换同花顺行业原生日K网关(完整OHLCV+真实成交额口径)；同花顺源日更时点可能滞后，使用前核对 latest_date；amount_ratio_1d 即板块资金延续评分成交连续度 V 项的直接输入",
                    }
                    if n < count:
                        res["data_status"] = "partial"
                        res["note"] += f"；实际仅取得 {n} 根 (不足请求的 {count} 根)"
                    set_cached(cache_key, res, ttl=ttl_for_history(rows[-1]["date"]))
                    return res
            failed_sources.append("ths_native_kline(响应无有效K线)")
        except Exception as exc:
            failed_sources.append(f"ths_native_kline({type(exc).__name__})")

    # 备源 2: fflow daykline (收盘序列 + 主力净额, 无盘中高低价与成交额)
    url = (
        "/api/qt/stock/fflow/daykline/get"
        f"?lmt={count}&klt=101&secid=90.{sector_code}&secid2=90.{sector_code}"
        "&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65"
    )
    try:
        data = json.loads(em_kline_get(url, timeout=5)).get("data") or {}
        klines = data.get("klines") or []
        if len(klines) >= 2:
            rows = []
            for line in klines[-count:]:
                parts = line.split(",")
                if len(parts) >= 13:
                    rows.append({
                        "date": parts[0],
                        "close": safe_float(parts[11], 0.0),
                        "change_pct": f"{safe_float(parts[12], 0.0):+.2f}%",
                        "main_net_inflow_billion": round(safe_float(parts[1], 0.0) / 100000000.0, 2),
                    })
            closes = [r["close"] for r in rows]
            n = len(closes)
            if n >= 2 and closes[-1] > 0:
                res = {
                    "source": "P3_Eastmoney_Sector_Kline",
                    "data_status": "ok",
                    "ohlc_source": False,
                    "sector_code": sector_code,
                    "sector_name": data.get("name", sector),
                    "valid_bars": n,
                    "latest_date": rows[-1]["date"],
                    "latest_close": closes[-1],
                    "latest_change_pct": rows[-1]["change_pct"],
                    "ma5": _sector_ma(closes, 5),
                    "ma10": _sector_ma(closes, 10),
                    "ma20": _sector_ma(closes, 20),
                    "ma60": _sector_ma(closes, 60),
                    "recent_5d_return": _sector_return(closes, 5),
                    "recent_20d_return": _sector_return(closes, 20),
                    "recent_60d_return": _sector_return(closes, 60),
                    "high_close_20d": max(closes[-min(20, n):]),
                    "low_close_20d": min(closes[-min(20, n):]),
                    "high_close_60d": max(closes[-min(60, n):]),
                    "low_close_60d": min(closes[-min(60, n):]),
                    "cum_main_net_inflow_5d_billion": round(sum(r["main_net_inflow_billion"] for r in rows[-5:]), 2),
                    "cum_main_net_inflow_20d_billion": round(sum(r["main_net_inflow_billion"] for r in rows[-min(20, n):]), 2),
                    "note": "收盘序列来自东财板块资金流日K网关 (无盘中高低价与成交额, 高低点为收盘价口径)；近5/20日主力净流入累计为板块资金延续证据",
                }
                if n < count:
                    res["data_status"] = "partial"
                    res["note"] += f"；实际仅取得 {n} 根 (不足请求的 {count} 根)"
                set_cached(cache_key, res, ttl=ttl_for_history(rows[-1]["date"]))
                return res
        failed_sources.append("eastmoney_fflow_daykline(响应无有效K线)")
    except Exception as exc:
        failed_sources.append(f"eastmoney_fflow_daykline({type(exc).__name__})")

    # 兜底2: 若东财板块K线与资金流日K皆不可用，但该板块在 STATIC_SECTOR_BASKETS 中，自动由 fetch_basket_index 构造等权代理日K
    try:
        basket_stocks = STATIC_SECTOR_BASKETS.get(sector_code)
        if not basket_stocks:
            for k, v in STATIC_SECTOR_MAP.items():
                if v == sector_code and v in STATIC_SECTOR_BASKETS:
                    basket_stocks = STATIC_SECTOR_BASKETS[v]
                    break
        if basket_stocks:
            basket_res = fetch_basket_index(basket_stocks, count=min(count, 60))
            if isinstance(basket_res, dict) and not basket_res.get("error") and basket_res.get("series"):
                bars = basket_res.get("series", [])
                closes = [b["level"] for b in bars]
                n = len(closes)
                if n >= 2:
                    res = {
                        "source": "P3_Constructed_Basket_Proxy",
                        "data_status": "partial",
                        "ohlc_source": False,
                        "sector_code": sector_code,
                        "sector_name": sector,
                        "valid_bars": n,
                        "latest_date": bars[-1]["date"],
                        "latest_close": closes[-1],
                        "latest_change_pct": bars[-1].get("change_pct", "0.00%"),
                        "ma5": _sector_ma(closes, 5),
                        "ma10": _sector_ma(closes, 10),
                        "ma20": _sector_ma(closes, 20),
                        "ma60": _sector_ma(closes, 60),
                        "recent_5d_return": _sector_return(closes, 5),
                        "recent_20d_return": _sector_return(closes, 20),
                        "recent_60d_return": _sector_return(closes, 60),
                        "note": f"东财板块日K源不可用，已自动采用核心权重股 ({','.join(basket_stocks)}) 等权篮子代理序列（日度再平衡口径，仅供方向参考）",
                    }
                    set_cached(cache_key, res, ttl=ttl_for_history(bars[-1]["date"]))
                    return res
    except Exception:
        pass

    return {
        "error": f"未获取到板块日K序列: {sector}",
        "data_status": "unavailable",
        "source_unavailable": True,
        "unavailable_sources": failed_sources,
        "note": "东财板块K线网关临时不可用 (含镜像域名), 同花顺与资金流日K兜底亦未取到有效数据; 稍后重试",
        "hint": "可改用 get_basket_index 传入板块主要成分股构造等权代理序列 (使用边界见公共研究契约)",
    }


def fetch_basket_index(stocks: List[str], count: int = 20) -> Dict[str, Any]:
    """
    以腾讯前复权日K构造等权篮子指数（日度再平衡口径：篮子日收益 = 成分股当日收益的等权均值）
    用途：东财板块指数网关抖动时的代理序列（如保险 BK0474、银行 BK0475 等大票行业，等权覆盖度高）、
    主线篮子相对强度对照。输出为构造序列（series_type=equal_weight_constructed），
    只能用于方向性对照，不得用于精确评分阈值——使用边界见公共研究契约
    """
    if not isinstance(stocks, list) or len(stocks) < 2 or len(stocks) > 10:
        return {"error": "stocks 必须是 2 至 10 个标的的数组", "data_status": "unavailable"}
    if not all(isinstance(s, str) and s.strip() for s in stocks):
        return {"error": "stocks 必须是非空字符串数组", "data_status": "unavailable"}
    if not isinstance(count, int) or not 5 <= count <= 60:
        return {"error": "count 必须是 5 至 60 的整数", "data_status": "unavailable"}

    cache_key = f"basket_{'|'.join(dict.fromkeys(s.strip() for s in stocks))}_{count}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    # 1. 逐标的拉取前复权收盘序列 (去重; 停牌/未上市日期自然缺失, 由 ffill 与按日可用集处理)
    series_by_stock: Dict[str, Dict[str, float]] = {}
    succeeded: List[str] = []
    failed: List[str] = []
    for raw in dict.fromkeys(stocks):
        ts_code = normalize_symbol(raw)
        try:
            url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param={ts_code},day,,,{count + 1},qfq"
            data = json.loads(http_get(url, timeout=5)).get("data", {}).get(ts_code, {})
            bars = data.get("qfqday") or []
            if not bars:
                # 与 fetch_stock_kline 的前复权硬门槛保持一致：缺失前复权序列即判失败，
                # 不得静默回退未复权 day 序列，否则同一篮子内会混用两种复权口径污染相对强度。
                failed.append(f"{raw}(无前复权序列)")
                continue
            closes = {str(r[0]): float(r[2]) for r in bars[-(count + 1):] if len(r) >= 3}
            if len(closes) >= 2:
                series_by_stock[ts_code] = closes
                succeeded.append(f"{raw}({ts_code})")
            else:
                failed.append(str(raw))
        except Exception:
            failed.append(str(raw))

    if len(series_by_stock) < 2:
        return {
            "error": f"有效成分股不足 2 只 (成功: {succeeded or '无'}; 失败: {failed or '无'})",
            "data_status": "unavailable",
        }

    # 2. 交易日并集 + 逐标的 ffill; 每日收益只纳入当日有前收盘价的标的
    all_dates = sorted({d for s in series_by_stock.values() for d in s})
    basket_dates = all_dates[-(count + 1):]
    if len(basket_dates) < 2:
        return {"error": "有效交易日不足", "data_status": "unavailable"}

    levels: List[Dict[str, Any]] = []
    level = 100.0
    prev_date: Optional[str] = None
    for d in basket_dates:
        if prev_date is not None:
            rets = []
            for closes in series_by_stock.values():
                cur = closes.get(d) or _last_close_on_or_before(closes, d)
                prev = closes.get(prev_date) or _last_close_on_or_before(closes, prev_date)
                if cur is not None and prev is not None and prev > 0:
                    rets.append(cur / prev - 1.0)
            if rets:
                level *= (1.0 + sum(rets) / len(rets))
            levels.append({
                "date": d,
                "level": round(level, 2),
                "change_pct": f"{(sum(rets) / len(rets) * 100):+.2f}%" if rets else "0.00%",
                "stocks_counted": len(rets),
            })
        else:
            levels.append({"date": d, "level": 100.0, "change_pct": "0.00% (基期)", "stocks_counted": len(series_by_stock)})
        prev_date = d

    ret_5 = _basket_return(levels, 5)
    ret_20 = _basket_return(levels, 20)
    res = {
        "source": "P3_Tencent_Constructed_Basket",
        "data_status": "partial" if failed else "ok",
        "series_type": "equal_weight_constructed",
        "basket_size": len(series_by_stock),
        "stocks_succeeded": succeeded,
        "stocks_failed": failed,
        "valid_bars": len(levels) - 1,
        "latest_date": levels[-1]["date"],
        "latest_level": levels[-1]["level"],
        "recent_5d_return": ret_5,
        "recent_20d_return": ret_20,
        "series": levels,
        "note": ("等权构造序列 (日度再平衡口径, 腾讯前复权收盘): 与板块官方市值加权指数存在口径差异, "
                 "只能用于方向性强弱对照, 不得用于精确评分阈值或赔率计算; 报告中必须标注'代理序列'并披露成分覆盖度"),
    }
    if failed:
        res["note"] += f"；未纳入成分: {', '.join(failed)}"
    set_cached(cache_key, res, ttl=300)
    return res


def _last_close_on_or_before(closes: Dict[str, float], date_str: str) -> Optional[float]:
    """返回 closes 中不晚于 date_str 的最近收盘价 (处理停牌/迟到上市)"""
    earlier = [d for d in closes if d <= date_str]
    return closes[max(earlier)] if earlier else None


def _basket_return(levels: List[Dict[str, Any]], window: int) -> str:
    if len(levels) < window + 1:
        w = len(levels) - 1
    else:
        w = window
    if w <= 0 or levels[-(w + 1)]["level"] <= 0:
        return "N/A"
    return f"{((levels[-1]['level'] - levels[-(w + 1)]['level']) / levels[-(w + 1)]['level'] * 100):+.2f}%"


def fetch_sector_fund_flow(count: int = 20, days: int = 1) -> Dict[str, Any]:
    """
    获取 A 股全行业板块主力资金流向、涨跌幅排行与领涨龙头；days>1 时附各板块 N 日主力净流入历史
    直供 daily-review L2 强势板块定位与 sector-rotation 5日资金迁移分析
    """
    if not isinstance(count, int) or not 1 <= count <= 100:
        return {"error": "count 必须是 1 至 100 的整数", "data_status": "unavailable"}
    if not isinstance(days, int) or not 1 <= days <= 10:
        return {"error": "days 必须是 1 至 10 的整数", "data_status": "unavailable"}
    if days > 1 and count > 12:
        return {"error": "days > 1 时 count 上限为 12 (控制上游请求数)", "data_status": "unavailable"}

    cache_key = f"sector_fund_flow_{count}_{days}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    try:
        # 全量翻页聚合: 行业板块 total 已超单页 100 上限, 不翻页会截断流出榜尾部
        data = fetch_industry_board_rows("f12,f14,f2,f3,f62,f184,f204,f205", fid="f62")
        if not data:
            return {"error": "未获取到行业资金流数据"}

        sectors = []
        for item in data:
            net_inflow_yuan = safe_float(item.get("f62"), 0.0)
            net_inflow_billion = round(net_inflow_yuan / 100000000.0, 2)
            sectors.append({
                "code": item.get("f12"),
                "name": item.get("f14"),
                "change_pct": f"{safe_float(item.get('f3'), 0.0):+.2f}%",
                "change_val": safe_float(item.get("f3"), 0.0),
                "net_inflow_billion": net_inflow_billion,
                "net_inflow_ratio": f"{safe_float(item.get('f184'), 0.0):+.2f}%",
                "top_stock_name": item.get("f204", "--"),
                "top_stock_code": item.get("f205", "--"),
            })

        sorted_by_inflow = sorted(sectors, key=lambda x: x["net_inflow_billion"], reverse=True)
        top_inflows = sorted_by_inflow[:count]
        top_outflows = sorted_by_inflow[-count:][::-1]

        sorted_by_gain = sorted(sectors, key=lambda x: x["change_val"], reverse=True)
        top_gainers = sorted_by_gain[:count]
        top_losers = sorted_by_gain[-count:][::-1]

        res = {
            "source": "P3_Eastmoney_Sector_Fund_Flow",
            "data_status": "ok",
            "sector_taxonomy": "eastmoney_industry",
            "total_sectors_tracked": len(sectors),
            "top_inflow_sectors": [
                {
                    "rank": i + 1,
                    "name": s["name"],
                    "code": s["code"],
                    "change_pct": s["change_pct"],
                    "net_inflow_billion": f"{s['net_inflow_billion']:+.2f} 亿",
                    "inflow_ratio": s["net_inflow_ratio"],
                    "leading_stock": f"{s['top_stock_name']}({s['top_stock_code']})",
                }
                for i, s in enumerate(top_inflows)
            ],
            "top_outflow_sectors": [
                {
                    "rank": i + 1,
                    "name": s["name"],
                    "code": s["code"],
                    "change_pct": s["change_pct"],
                    "net_outflow_billion": f"{s['net_inflow_billion']:+.2f} 亿",
                    "leading_stock": f"{s['top_stock_name']}({s['top_stock_code']})",
                }
                for i, s in enumerate(top_outflows)
            ],
            "top_gainer_sectors": [
                {
                    "rank": i + 1,
                    "name": s["name"],
                    "change_pct": s["change_pct"],
                    "net_inflow": f"{s['net_inflow_billion']:+.2f} 亿",
                    "leader": f"{s['top_stock_name']}({s['top_stock_code']})",
                }
                for i, s in enumerate(top_gainers)
            ],
            "top_loser_sectors": [
                {
                    "rank": i + 1,
                    "name": s["name"],
                    "change_pct": s["change_pct"],
                    "net_inflow": f"{s['net_inflow_billion']:+.2f} 亿",
                }
                for i, s in enumerate(top_losers)
            ],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        # days > 1: 对流入/流出榜板块逐个回补主力资金 N 日历史 (单板块失败不影响整体, 标记 partial)
        if days > 1:
            target_codes = list(dict.fromkeys([s["code"] for s in top_inflows + top_outflows]))
            history_map: Dict[str, List[Dict[str, Any]]] = {}
            failed_history: List[str] = []
            for code in target_codes:
                try:
                    history_map[str(code)] = fetch_sector_fund_history(str(code), days)
                except Exception:
                    failed_history.append(str(next((s["name"] for s in sectors if s["code"] == code), code)))
                time.sleep(0.12)  # 批量回补时节流, 避免触发上游限流
            for entry in res["top_inflow_sectors"] + res["top_outflow_sectors"]:
                hist = history_map.get(str(entry.get("code")))
                if hist:
                    entry["history"] = hist
                    entry["cum_net_inflow_billion"] = round(
                        sum(h["main_net_inflow_billion"] for h in hist), 2)
                    entry["fund_flow_trend"] = fund_flow_trend_label(hist)
            res["history_days"] = days
            if failed_history:
                res["data_status"] = "partial"
                res["history_unavailable_sectors"] = failed_history

        set_cached(cache_key, res)
        return res
    except Exception as e:
        # 降级备源 1: 同花顺全行业资金流网关 (含50大行业真实主力净流入额、流入流出、领涨股)
        try:
            ths_url = "https://data.10jqka.com.cn/funds/hyzjl/"
            ths_raw = http_get(ths_url, timeout=5, encoding="gbk")
            rows = re.findall(r'<tr[^>]*>(.*?)</tr>', ths_raw, re.DOTALL)
            sectors = []
            for r in rows[1:]:
                cols = [re.sub(r'<[^>]+>', '', c).strip() for c in re.findall(r'<td[^>]*>(.*?)</td>', r, re.DOTALL)]
                if len(cols) >= 10:
                    code_match = re.search(r'/detail/code/(\d+)/', r)
                    ths_code = code_match.group(1) if code_match else ''
                    stock_match = re.search(r'stockpage\.10jqka\.com\.cn/(\d+)/', r)
                    stock_code = stock_match.group(1) if stock_match else ''
                    s_name = cols[1]
                    # 兜底循环仅查静态表, 不走在线解析: 逐名联想曾实测 42.9s/135 次调用;
                    # 静态未命中的行业保留 THS_881xxx 原生身份 (sector_taxonomy=ths_industry 口径自洽)
                    stripped_name = s_name.rstrip("行业").rstrip("板块")
                    s_code = (STATIC_SECTOR_MAP.get(s_name)
                              or STATIC_SECTOR_MAP.get(stripped_name)
                              or (f"THS_{ths_code}" if ths_code else "N/A"))
                    chg_val = safe_float(cols[3].rstrip("%"), 0.0)
                    net_inflow_b = safe_float(cols[6], 0.0)
                    inflow_b = safe_float(cols[4], 0.0)
                    outflow_b = safe_float(cols[5], 0.0)
                    turnover_b = round(inflow_b + outflow_b, 2)
                    sectors.append({
                        "code": s_code,
                        "ths_code": ths_code,
                        "name": s_name,
                        "change_pct": f"{chg_val:+.2f}%",
                        "change_val": chg_val,
                        "turnover_billion": turnover_b,
                        "net_inflow_billion": net_inflow_b,
                        "top_stock_name": cols[8],
                        "top_stock_code": stock_code,
                        "top_stock_pct": cols[9],
                    })
            if sectors:
                sorted_by_inflow = sorted(sectors, key=lambda x: x["net_inflow_billion"], reverse=True)
                top_inflows = sorted_by_inflow[:count]
                top_outflows = sorted_by_inflow[-count:][::-1]

                sorted_by_gain = sorted(sectors, key=lambda x: x["change_val"], reverse=True)
                top_gainers = sorted_by_gain[:count]
                top_losers = sorted_by_gain[-count:][::-1]

                fallback_res = {
                    "source": "P3_THS_Sector_Fund_Flow",
                    "data_status": "partial",
                    "sector_taxonomy": "ths_industry",
                    "unavailable_sources": [f"eastmoney_main_net_flow({type(e).__name__})"],
                    "note": f"东财主力净流入不可用({type(e).__name__})，已切换同花顺行业资金流网关；板块名称为同花顺行业口径(与东财行业板块不同体系, 如传媒↔文化传媒)，主力净流入为实时口径，跨时点对比前先核对 sector_taxonomy",
                    "total_sectors_tracked": len(sectors),
                    "top_inflow_sectors": [
                        {
                            "rank": i + 1,
                            "name": s["name"],
                            "code": s["code"],
                            "change_pct": s["change_pct"],
                            "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                            "net_inflow_billion": f"{s['net_inflow_billion']:+.2f} 亿",
                            "leading_stock": f"{s['top_stock_name']}({s['top_stock_code']})" if s['top_stock_code'] else s['top_stock_name'],
                        }
                        for i, s in enumerate(top_inflows)
                    ],
                    "top_outflow_sectors": [
                        {
                            "rank": i + 1,
                            "name": s["name"],
                            "code": s["code"],
                            "change_pct": s["change_pct"],
                            "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                            "net_outflow_billion": f"{s['net_inflow_billion']:+.2f} 亿",
                            "leading_stock": f"{s['top_stock_name']}({s['top_stock_code']})" if s['top_stock_code'] else s['top_stock_name'],
                        }
                        for i, s in enumerate(top_outflows)
                    ],
                    "top_gainer_sectors": [
                        {
                            "rank": i + 1,
                            "name": s["name"],
                            "code": s["code"],
                            "change_pct": s["change_pct"],
                            "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                            "net_inflow": f"{s['net_inflow_billion']:+.2f} 亿",
                            "leader": f"{s['top_stock_name']}({s['top_stock_code']})" if s['top_stock_code'] else s['top_stock_name'],
                        }
                        for i, s in enumerate(top_gainers)
                    ],
                    "top_loser_sectors": [
                        {
                            "rank": i + 1,
                            "name": s["name"],
                            "code": s["code"],
                            "change_pct": s["change_pct"],
                            "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                            "net_inflow": f"{s['net_inflow_billion']:+.2f} 亿",
                        }
                        for i, s in enumerate(top_losers)
                    ],
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                if days > 1:
                    # 同花顺兜底无 N 日历史回补能力, 必须显式声明而非静默省略 (曾致资金延续结论不可复现)
                    fallback_res["history_days"] = days
                    fallback_res["history_unavailable"] = True
                    fallback_res["history_unavailable_reason"] = "同花顺兜底源仅提供当日主力净流入, 不支持 N 日历史回补; history/cum/trend 字段仅在东财主源 (sector_taxonomy=eastmoney_industry) 下提供"
                set_cached(cache_key, fallback_res)
                return fallback_res
        except Exception:
            pass

        # 降级备源 2: 新浪全行业 49 大板块实时网关 (总成交额与涨跌排行口径)
        try:
            sina_url = "https://money.finance.sina.com.cn/q/view/newSinaHy.php"
            sina_raw = http_get(sina_url, timeout=5, encoding="gbk")
            if "=" in sina_raw:
                payload_str = sina_raw.split("=", 1)[1].strip().rstrip(";")
                sina_data = json.loads(payload_str)
                sectors = []
                for _, val_str in sina_data.items():
                    parts = val_str.split(",")
                    if len(parts) >= 13:
                        s_name = parts[1].strip()
                        s_code = resolve_sector_code(s_name) or "N/A"
                        chg = safe_float(parts[5], 0.0)
                        turnover_b = round(safe_float(parts[7], 0.0) / 100000000.0, 2)
                        sectors.append({
                            "code": s_code,
                            "name": s_name,
                            "change_pct": f"{chg:+.2f}%",
                            "change_val": chg,
                            "turnover_billion": turnover_b,
                            "net_inflow_billion": 0.0,
                            "top_stock_name": parts[12].strip(),
                            "top_stock_code": parts[8].strip(),
                        })
                if sectors:
                    sorted_by_turnover = sorted(sectors, key=lambda x: x["turnover_billion"], reverse=True)
                    top_turnovers = sorted_by_turnover[:count]
                    sorted_by_gain = sorted(sectors, key=lambda x: x["change_val"], reverse=True)
                    top_gainers = sorted_by_gain[:count]
                    top_losers = sorted_by_gain[-count:][::-1]

                    fallback_res = {
                        "source": "P3_Sina_Industry_Fallback",
                        "data_status": "partial",
                        "sector_taxonomy": "sina_industry",
                        "unavailable_sources": [f"eastmoney_main_net_flow({type(e).__name__})", "ths_industry_fund_flow"],
                        "note": f"东财主力净流入上游不可用({type(e).__name__})，已降级为新浪行业全景网关(全天总成交额与涨跌排行口径)；跨时点对比前先核对 sector_taxonomy",
                        "total_sectors_tracked": len(sectors),
                        "top_inflow_sectors": [
                            {
                                "rank": i + 1,
                                "name": s["name"],
                                "code": s["code"],
                                "change_pct": s["change_pct"],
                                "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                                "net_inflow_billion": "N/A (新浪降级)",
                                "leading_stock": f"{s['top_stock_name']}({s['top_stock_code']})",
                            }
                            for i, s in enumerate(top_turnovers)
                        ],
                        "top_gainer_sectors": [
                            {
                                "rank": i + 1,
                                "name": s["name"],
                                "code": s["code"],
                                "change_pct": s["change_pct"],
                                "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                                "leader": f"{s['top_stock_name']}({s['top_stock_code']})",
                            }
                            for i, s in enumerate(top_gainers)
                        ],
                        "top_loser_sectors": [
                            {
                                "rank": i + 1,
                                "name": s["name"],
                                "code": s["code"],
                                "change_pct": s["change_pct"],
                            "turnover_billion": f"{s['turnover_billion']:.2f} 亿",
                        }
                        for i, s in enumerate(top_losers)
                    ],
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    if days > 1:
                        fallback_res["history_days"] = days
                        fallback_res["history_unavailable"] = True
                        fallback_res["history_unavailable_reason"] = "新浪兜底源仅提供当日总成交额与涨跌排行, 无主力净流入及 N 日历史"
                    set_cached(cache_key, fallback_res)
                    return fallback_res
        except Exception:
            pass
        return {"error": f"获取行业资金流向出错: {str(e)}"}


def fetch_longhubang_detail(symbol: Optional[str] = None, date_str: Optional[str] = None) -> Dict[str, Any]:
    """
    获取 A 股交易所公开龙虎榜席位明细（全市场概览或个股前五大买卖席位穿透）
    直供 daily-review 席位品质与 stock-analysis L5 筹码结构
    """
    clean_symbol = symbol.strip() if symbol else ""
    if clean_symbol:
        code_only = clean_symbol.split(".")[0].replace("sh", "").replace("sz", "").replace("bj", "")
    else:
        code_only = ""

    norm_date = normalize_date_str(date_str) if date_str else None
    if date_str and not norm_date:
        return {"error": "date_str 必须为 YYYYMMDD 或 YYYY-MM-DD", "data_status": "unavailable"}

    cache_key = f"lhb_{code_only}_{norm_date or 'latest'}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    try:
        if code_only:
            filter_expr = f'(SECURITY_CODE="{code_only}")'
            if norm_date:
                filter_expr += f"(TRADE_DATE='{norm_date}')"
            buy_url = (
                "https://datacenter-web.eastmoney.com/api/data/v1/get?"
                + urllib.parse.urlencode({
                    "reportName": "RPT_BILLBOARD_DAILYDETAILSBUY",
                    "columns": "ALL",
                    "pageNumber": 1,
                    "pageSize": 5,
                    "sortTypes": -1,
                    "sortColumns": "TRADE_DATE",
                    "filter": filter_expr,
                    "source": "WEB",
                    "client": "WEB",
                })
            )
            sell_url = (
                "https://datacenter-web.eastmoney.com/api/data/v1/get?"
                + urllib.parse.urlencode({
                    "reportName": "RPT_BILLBOARD_DAILYDETAILSSELL",
                    "columns": "ALL",
                    "pageNumber": 1,
                    "pageSize": 5,
                    "sortTypes": -1,
                    "sortColumns": "TRADE_DATE",
                    "filter": filter_expr,
                    "source": "WEB",
                    "client": "WEB",
                })
            )
            summary_url = (
                "https://datacenter-web.eastmoney.com/api/data/v1/get?"
                + urllib.parse.urlencode({
                    "reportName": "RPT_BILLBOARD_DAILYDETAILS",
                    "columns": "ALL",
                    "pageNumber": 1,
                    "pageSize": 1,
                    "sortTypes": -1,
                    "sortColumns": "TRADE_DATE",
                    "filter": filter_expr,
                    "source": "WEB",
                    "client": "WEB",
                })
            )
            buy_rows = em_dc_rows(json.loads(http_get(buy_url, timeout=4)))

            sell_rows = em_dc_rows(json.loads(http_get(sell_url, timeout=4)))

            sum_rows = em_dc_rows(json.loads(http_get(summary_url, timeout=4)))

            if not buy_rows and not sell_rows and not sum_rows:
                return {
                    "source": "P3_Eastmoney_LHB_Details",
                    "data_status": "ok",
                    "symbol": symbol,
                    "status": "未上榜 / 近期无龙虎榜记录",
                    "explanation": "标的近期未触发龙虎榜披露标准 (日涨跌偏离度达7%或日换手达20%等)",
                }

            sum_item = sum_rows[0] if sum_rows else {}
            trade_date = (sum_item.get("TRADE_DATE") or (buy_rows[0].get("TRADE_DATE") if buy_rows else "近期"))[:10]

            def parse_seat(row):
                dept_name = row.get("OPERATEDEPT_NAME", "")
                buy_amt = round(safe_float(row.get("BUY"), 0.0) / 10000.0, 2)
                sell_amt = round(safe_float(row.get("SELL"), 0.0) / 10000.0, 2)
                net_amt = round(safe_float(row.get("NET"), 0.0) / 10000.0, 2)
                seat_type = "机构专用" if "机构" in dept_name else ("北向专用" if ("深股通" in dept_name or "沪股通" in dept_name) else "游资营业部")
                return {
                    "seat_name": dept_name,
                    "seat_type": seat_type,
                    "buy_wan": f"{buy_amt:+.2f} 万",
                    "sell_wan": f"{sell_amt:+.2f} 万",
                    "net_wan": f"{net_amt:+.2f} 万",
                }

            buyer_seats = [parse_seat(r) for r in buy_rows]
            seller_seats = [parse_seat(r) for r in sell_rows]

            # 机构专用席位净额: 买卖两榜合并到席位粒度再取 NET 合计 (单边 BUY/SELL 相减会丢失席位自身对冲)
            org_seats: Dict[str, Dict[str, float]] = {}
            for r in buy_rows + sell_rows:
                dept = r.get("OPERATEDEPT_NAME", "") or ""
                if "机构" not in dept:
                    continue
                cur = org_seats.setdefault(dept, {"buy": 0.0, "sell": 0.0, "net": 0.0})
                cur["buy"] += safe_float(r.get("BUY"), 0.0) or 0.0
                cur["sell"] += safe_float(r.get("SELL"), 0.0) or 0.0
                cur["net"] += safe_float(r.get("NET"), 0.0) or 0.0
            org_net_wan = round(sum(v["net"] for v in org_seats.values()) / 10000.0, 2)

            res = {
                "source": "P3_Eastmoney_LHB_Details",
                "data_status": "ok",
                "symbol": symbol,
                "name": sum_item.get("SECURITY_NAME_ABBR", symbol),
                "trade_date": trade_date,
                "explanation": sum_item.get("EXPLANATION", "上榜异动"),
                "total_lhb_buy_million": round(safe_float(sum_item.get("TOTAL_BUY"), 0.0) / 1000000.0, 2),
                "total_lhb_sell_million": round(safe_float(sum_item.get("TOTAL_SELL"), 0.0) / 1000000.0, 2),
                "total_lhb_net_million": round(safe_float(sum_item.get("TOTAL_NET"), 0.0) / 1000000.0, 2),
                "org_seat_net_wan": f"{org_net_wan:+.2f} 万元",
                "org_seat_count": len(org_seats),
                "org_seat_net_details": [
                    {
                        "seat_name": dept,
                        "buy_wan": f"{v['buy'] / 10000.0:+.2f} 万",
                        "sell_wan": f"{v['sell'] / 10000.0:+.2f} 万",
                        "net_wan": f"{v['net'] / 10000.0:+.2f} 万",
                    }
                    for dept, v in sorted(org_seats.items(), key=lambda kv: kv[1]["net"], reverse=True)
                ],
                "seat_quality_judgment": "机构席位净买入" if org_net_wan > 0 else ("机构席位净卖出" if org_net_wan < 0 else "未见机构席位净方向"),
                "seat_quality_note": "仅基于披露席位的机构专用净额，不推断外资、游资或散户资金性质。",
                "top5_buyers": buyer_seats,
                "top5_sellers": seller_seats,
            }
            set_cached(cache_key, res, ttl=ttl_for_history(trade_date))
            return res

        else:
            filter_expr = f"(TRADE_DATE='{norm_date}')" if norm_date else ""
            params = {
                "reportName": "RPT_BILLBOARD_DAILYDETAILS",
                "columns": "ALL",
                "pageNumber": 1,
                "pageSize": 20,
                "sortTypes": -1,
                "sortColumns": "TOTAL_NET",
                "source": "WEB",
                "client": "WEB",
            }
            if filter_expr:
                params["filter"] = filter_expr

            url = "https://datacenter-web.eastmoney.com/api/data/v1/get?" + urllib.parse.urlencode(params)
            data_rows = em_dc_rows(json.loads(http_get(url, timeout=4)))

            stocks = []
            for r in data_rows:
                net_amt_wan = round(safe_float(r.get("TOTAL_NET"), 0.0) / 10000.0, 2)
                stocks.append({
                    "code": r.get("SECURITY_CODE"),
                    "name": r.get("SECURITY_NAME_ABBR"),
                    "change_pct": f"{safe_float(r.get('CHANGE_RATE'), 0.0):+.2f}%",
                    "close_price": safe_float(r.get("CLOSE_PRICE"), 0.0),
                    "net_inflow_wan": f"{net_amt_wan:+.2f} 万",
                    "turnover_rate": f"{safe_float(r.get('TURNRATE'), 0.0):.2f}%",
                    "reason": r.get("EXPLANATION", ""),
                })

            # 自动为龙虎榜净买入前 3 只核心标的穿透席位画像，避免二次调用导致数据缺失
            seat_previews = []
            for item in stocks[:3]:
                c = item.get("code")
                if c:
                    try:
                        detail = fetch_longhubang_detail(symbol=c, date_str=norm_date)
                        if isinstance(detail, dict) and not detail.get("error"):
                            top_b = detail.get("top5_buyers", [{}])[0].get("seat_name") if detail.get("top5_buyers") else "--"
                            top_s = detail.get("top5_sellers", [{}])[0].get("seat_name") if detail.get("top5_sellers") else "--"
                            preview = {
                                "code": c,
                                "name": item.get("name"),
                                "org_seat_net": detail.get("org_seat_net_wan"),
                                "seat_judgment": detail.get("seat_quality_judgment"),
                                "top_buyer": top_b,
                                "top_seller": top_s,
                            }
                            item["seat_preview"] = preview
                            seat_previews.append(preview)
                    except Exception:
                        pass

            res = {
                "source": "P3_Eastmoney_LHB_Daily_Summary",
                "data_status": "ok",
                "date": norm_date or (data_rows[0].get("TRADE_DATE", "")[:10] if data_rows else datetime.now().strftime("%Y-%m-%d")),
                "total_stocks_on_list": len(stocks),
                "top_net_buy_stocks": stocks[:10],
                "core_seat_previews": seat_previews,
            }
            set_cached(cache_key, res, ttl=ttl_for_history(res["date"]))
            return res

    except Exception as e:
        return {"error": f"获取龙虎榜席位明细出错: {str(e)}"}


def fetch_company_quality(symbol: str) -> Dict[str, Any]:
    """
    获取 A 股个股基本面质量、财务指标、商誉、解禁与排雷数据
    直接满足 stock-analysis L8 公司质量与事件风险评估
    东财 datacenter 对无记录/被频控标的返回 {"success": false, "result": null}，
    因此各段查询独立容错：单段失败或为空仅降级为 N/A 与告警，不拖垮整体排雷结果
    """
    clean_symbol = symbol.strip()
    code_only = clean_symbol.split(".")[0].replace("sh", "").replace("sz", "").replace("bj", "")
    cache_key = f"quality_{code_only}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    def dc_rows(report_name: str, page_size: int, sort_types: int, sort_columns: str) -> Tuple[List[Dict[str, Any]], Optional[str]]:
        url = (
            "https://datacenter-web.eastmoney.com/api/data/v1/get?"
            + urllib.parse.urlencode({
                "reportName": report_name,
                "columns": "ALL",
                "pageNumber": 1,
                "pageSize": page_size,
                "sortTypes": sort_types,
                "sortColumns": sort_columns,
                "filter": f'(SECURITY_CODE="{code_only}")',
                "source": "WEB",
                "client": "WEB",
            })
        )
        try:
            body = json.loads(http_get(url, timeout=4))
        except Exception as exc:
            return [], f"上游请求失败: {exc}"
        result = body.get("result")
        if not isinstance(result, dict):
            # result=null 是服务端对无记录标的的正常返回，不是异常
            return [], None
        data = result.get("data")
        return (data if isinstance(data, list) else []), None

    try:
        warnings_list: List[str] = []
        fina_rows, fina_err = dc_rows("RPT_F10_FINANCE_MAINFINADATA", 2, -1, "REPORT_DATE")
        if fina_err:
            warnings_list.append(f"财务指标查询失败: {fina_err}")
        # 解禁必须按 FREE_DATE 降序：升序会让历史解禁挤出 pageSize 窗口，漏报未来解禁
        lift_rows, lift_err = dc_rows("RPT_LIFT_STAGE", 5, -1, "FREE_DATE")
        if lift_err:
            warnings_list.append(f"解禁查询失败: {lift_err}")
        balance_rows, balance_err = dc_rows("RPT_DMSK_FN_BALANCE", 1, -1, "REPORT_DATE")
        if balance_err:
            warnings_list.append(f"资产负债查询失败: {balance_err}")

        f0 = fina_rows[0] if fina_rows else {}
        b0 = balance_rows[0] if balance_rows else {}

        if not f0 and not b0:
            return {
                "source": "P3_Eastmoney_Company_Quality_Gateway",
                "data_status": "unavailable",
                "symbol": symbol,
                "error": "该标的无财务指标/资产负债/解禁记录（可能未覆盖或数据源暂不可用），无法完成公司质量排雷筛查",
                "restricted_shares_lifting": [],
                "warnings": warnings_list,
            }

        if f0:
            report_period = f0.get("REPORT_DATE_NAME", "最新报告期")
            financial_summary = {
                "revenue_billion": f"{round(safe_float(f0.get('TOTALOPERATEREVE'), 0.0) / 100000000.0, 2)} 亿元",
                "revenue_yoy": f"{safe_float(f0.get('TOTALOPERATEREVETZ'), 0.0):+.2f}%",
                "net_profit_wan": f"{round(safe_float(f0.get('PARENTNETPROFIT'), 0.0) / 10000.0, 2)} 万元",
                "net_profit_yoy": f"{safe_float(f0.get('PARENTNETPROFITTZ'), 0.0):+.2f}%",
                "gross_margin": f"{safe_float(f0.get('XSMLL'), 0.0):.2f}%",
                "weighted_roe": f"{safe_float(f0.get('ROEJQ'), 0.0):.2f}%",
                "debt_to_assets_ratio": f"{safe_float(f0.get('ZCFZL'), 0.0):.2f}%",
                "operating_cashflow_per_share": f"{round(safe_float(f0.get('MGJYXJJE'), 0.0), 2)} 元",
            }
        else:
            report_period = "N/A"
            financial_summary = {
                key: "N/A" for key in (
                    "revenue_billion", "revenue_yoy", "net_profit_wan", "net_profit_yoy",
                    "gross_margin", "weighted_roe", "debt_to_assets_ratio", "operating_cashflow_per_share",
                )
            }

        if b0:
            goodwill_yuan = safe_float(b0.get("GOODWILL"), 0.0)
            total_equity_yuan = safe_float(b0.get("TOTAL_EQUITY"), None)
            # 净资产缺失时不得默认 1.0（会把商誉占比放大成天文数字并误报高风险）；
            # 净资产为负（资不抵债）时商誉占比无经济意义，须显式提示偿债风险而非置 0 掩盖。
            if total_equity_yuan is None:
                goodwill_ratio = None
                goodwill_note = "净资产字段缺失，商誉占比未计算"
            elif total_equity_yuan <= 0:
                goodwill_ratio = None
                goodwill_note = "净资产为负（资不抵债），商誉占比不适用，需单独评估偿债与退市风险"
            else:
                goodwill_ratio = round((goodwill_yuan / total_equity_yuan) * 100.0, 2)
                goodwill_note = None
            balance_and_goodwill = {
                "goodwill_million": f"{round(goodwill_yuan / 10000.0, 2)} 万元",
                "goodwill_to_equity_ratio": f"{goodwill_ratio:.2f}%" if goodwill_ratio is not None else "N/A",
                "inventory_million": f"{round(safe_float(b0.get('INVENTORY'), 0.0) / 10000.0, 2)} 万元",
            }
            if goodwill_note:
                balance_and_goodwill["goodwill_ratio_note"] = goodwill_note
        else:
            goodwill_ratio = None
            goodwill_note = None
            balance_and_goodwill = {
                "goodwill_million": "N/A",
                "goodwill_to_equity_ratio": "N/A",
                "inventory_million": "N/A",
            }

        future_lifts = []
        now_date = datetime.now().strftime("%Y-%m-%d")
        for lr in lift_rows:
            free_date_str = str(lr.get("FREE_DATE", ""))[:10]
            if free_date_str >= now_date:
                future_lifts.append({
                    "lift_date": free_date_str,
                    "lift_shares_wan": round(safe_float(lr.get("CURRENT_FREE_SHARES"), 0.0), 2),
                    "ratio_of_total_shares": f"{(safe_float(lr.get('TOTAL_RATIO'), 0.0) * 100):.2f}%",
                    "shares_type": lr.get("FREE_SHARES_TYPE", "首发原股东/定增"),
                    "is_future": True,
                })

        restricted_note = ""
        if not lift_err and not lift_rows:
            restricted_note = "该标的数据源无解禁记录（可能未覆盖或已全部解禁），不构成排雷异常"

        audit_opinion_status = "N/A（当前数据源未提供审计意见；需以年度审计报告或交易所公告核验）"

        debt_val = safe_float(f0.get("ZCFZL"), 0.0) if f0 else None
        risk_level = "待补充核验"
        risk_reasons = []
        if debt_val is not None:
            if debt_val > 70:
                risk_level = "高"
                risk_reasons.append(f"资产负债率偏高 ({financial_summary['debt_to_assets_ratio']})")
            elif debt_val > 50:
                risk_level = "中"
                risk_reasons.append(f"资产负债率中等 ({financial_summary['debt_to_assets_ratio']})")
        else:
            risk_reasons.append("财务指标缺失，负债率筛查未执行")
        if goodwill_ratio is not None:
            if goodwill_ratio > 30:
                risk_level = "高"
                risk_reasons.append(f"商誉占净资产比例过高 ({goodwill_ratio}%)")
        elif goodwill_note:
            if "资不抵债" in goodwill_note:
                risk_level = "高"
            risk_reasons.append(goodwill_note)
        else:
            risk_reasons.append("资产负债数据缺失，商誉筛查未执行")
        if not risk_reasons:
            risk_reasons.append("仅完成负债率与商誉占比筛查；现金流、质押、减持、监管、诉讼及审计意见未覆盖")

        res = {
            "source": "P3_Eastmoney_Company_Quality_Gateway",
            "data_status": "partial",
            "symbol": symbol,
            "name": f0.get("SECURITY_NAME_ABBR", symbol) if f0 else symbol,
            "report_period": report_period,
            "financial_summary": financial_summary,
            "balance_and_goodwill": balance_and_goodwill,
            "restricted_shares_lifting": future_lifts[:3],
            "audit_opinion_status": audit_opinion_status,
            "company_risk_level": risk_level,
            "company_risk_assessment": "；".join(risk_reasons),
            "uncovered_risks": ["审计意见", "股权质押", "股东减持", "监管问询/处罚", "诉讼仲裁", "退市风险"],
        }
        if restricted_note:
            res["restricted_shares_lifting_note"] = restricted_note
        if warnings_list:
            res["warnings"] = warnings_list
        set_cached(cache_key, res, ttl=ttl_for_history(f0.get("REPORT_DATE") if f0 else None))
        return res

    except Exception as e:
        return {"error": f"获取公司质量排雷数据出错: {str(e)}"}


def fetch_stock_timeline(symbol: str) -> Dict[str, Any]:
    """
    获取 A 股个股当日分时走势全景、分时均线 (VWAP)、盘口放量脉冲与集合竞价数据
    支持数字代码或纯中文名称 (如 '301489', '贵州茅台')
    直供 market-prediction 竞价承接力研判与 stock-analysis 分时异动研判
    """
    ts_code = normalize_symbol(symbol)
    mkt = "1" if ts_code.startswith("sh") else "0"
    code = ts_code[2:] if len(ts_code) > 2 and ts_code.startswith(("sh", "sz", "bj")) else ts_code

    cache_key = f"timeline_{ts_code}"
    cached = get_cached(cache_key)
    if cached:
        return cached

    secid = f"{mkt}.{code}"
    url = f"https://push2.eastmoney.com/api/qt/stock/trends2/get?secid={secid}&fields1=f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13&fields2=f51,f52,f53,f54,f55,f56,f57,f58"
    try:
        raw = http_get(url, timeout=4)
        res_json = json.loads(raw)
        data = res_json.get("data", {})
        if not data or not data.get("trends"):
            return {"error": f"未获取到 {symbol} 的分时走势数据"}

        trends = data.get("trends", [])
        pre_close = safe_float(data.get("preClose"), 0.0)
        stock_name = data.get("name", symbol)

        parsed_points = []
        max_price = -1.0
        min_price = 9999999.0
        max_time = ""
        min_time = ""
        morning_point = None

        for item in trends:
            parts = item.split(",")
            if len(parts) < 8:
                continue
            tm_str = parts[0]
            c_p = safe_float(parts[2], 0.0)
            h_p = safe_float(parts[3], 0.0)
            l_p = safe_float(parts[4], 0.0)
            vol_hand = safe_float(parts[5], 0.0)
            amt_yuan = safe_float(parts[6], 0.0)
            avg_p = safe_float(parts[7], 0.0)

            if "09:25" in tm_str:
                morning_point = {
                    "time": tm_str,
                    "auction_price": c_p,
                    "auction_change_pct": f"{((c_p - pre_close) / pre_close * 100):+.2f}%" if pre_close > 0 else "0.00%",
                }

            if h_p > max_price:
                max_price = h_p
                max_time = tm_str
            if l_p < min_price and l_p > 0:
                min_price = l_p
                min_time = tm_str

            parsed_points.append({
                "time": tm_str,
                "price": c_p,
                "volume": vol_hand,
                "amount": amt_yuan,
                "avg_price": avg_p,
            })

        if not parsed_points:
            return {"error": "分时数据点解析为空"}

        latest = parsed_points[-1]
        latest_price = latest["price"]
        latest_avg = latest["avg_price"]
        latest_change_pct = f"{((latest_price - pre_close) / pre_close * 100):+.2f}%" if pre_close > 0 else "0.00%"
        bias_to_avg = f"{((latest_price - latest_avg) / latest_avg * 100):+.2f}%" if latest_avg > 0 else "0.00%"

        sorted_by_amt = sorted(parsed_points, key=lambda x: x["amount"], reverse=True)
        top_surge = [
            {
                "time": p["time"],
                "price": p["price"],
                "minute_amount_million": f"{round(p['amount'] / 1000000.0, 2)} 百万",
                "avg_price": p["avg_price"],
            }
            for p in sorted_by_amt[:3]
        ]

        if latest_price > latest_avg and safe_float(latest_change_pct.rstrip('%')) > 0:
            timeline_status = "强势放量：全天站上分时均线上方运行"
        elif latest_price < latest_avg:
            timeline_status = "弱势承压：处于分时均线下方震荡"
        else:
            timeline_status = "震荡拉锯：紧贴分时均线缠绕"

        res = {
            "source": "P3_Eastmoney_Intraday_Timeline",
            "data_status": "ok",
            "symbol": code,
            "ts_code": ts_code,
            "name": stock_name,
            "pre_close": pre_close,
            "latest_price": latest_price,
            "change_pct": latest_change_pct,
            "intraday_avg_price": latest_avg,
            "bias_to_avg_line": bias_to_avg,
            "intraday_high": f"{max_price} ({max_time})",
            "intraday_low": f"{min_price} ({min_time})",
            "morning_call_auction": morning_point or "9:25 未录入",
            "intraday_strength_label": timeline_status,
            "volume_surge_moments": top_surge,
            "total_intraday_points": len(parsed_points),
        }
        set_cached(cache_key, res)
        return res
    except Exception as e:
        return {"error": f"获取分时走势失败: {str(e)}"}


# -----------------------------------------------------------------------------
# 2.1 上下文聚合型数据包引擎 (Context-Oriented Aggregators)
# -----------------------------------------------------------------------------
def _make_context_envelope(
    context_name: str,
    payload: Dict[str, Any],
    missing: List[str],
    conflicts: Optional[List[str]] = None,
    data_date: Optional[str] = None,
    source: Optional[str] = None,
    core_data_available: Optional[bool] = None,
) -> Dict[str, Any]:
    """标准化上下文证据信封，保证统一输出与优雅降级。

    core_data_available 用于显式声明「核心真实数据块」是否有任意一块可用：
    - 传 False 时强制 data_status=unavailable，避免恒真存在的合成字段（如
      data_mode/archetype/position_context 等派生块）掩盖全量数据降级，
      让消费方正确识别「无真实数据」而非误判 partial。
    - 传 None 时回退到「payload 非空即 partial」的启发式，保持其它上下文行为不变。
    """
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S +08:00")
    today_date = date.today().strftime("%Y-%m-%d")
    total_expected = len(payload) + len(missing)
    if core_data_available is False:
        status = "unavailable"
    elif not missing:
        status = "ok"
    elif payload and len(payload) > 0:
        status = "partial"
    else:
        status = "unavailable"
    envelope = {
        "source": source or f"P3_MarketGraph_{context_name}",
        "source_family": "MarketGraph_Aggregator",
        "independence_group": "MarketGraph_Context",
        "data_status": status,
        "data_date": data_date or today_date,
        "as_of": now_str,
        "payload": payload,
        "missing": missing,
        "conflicts": conflicts or [],
    }
    if core_data_available is not None:
        envelope["core_data_available"] = core_data_available
    return envelope


def fetch_preopen_context(
    indices: Optional[List[str]] = None,
    date_str: Optional[str] = None,
    sectors: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """聚合 A 股盘前推演标准化证据包：T-1 指数日K与点位、市场情绪、连板天梯、市场广度"""
    idx_keys = indices or ["SHCI", "SZCI", "CYB", "CSIALL"]
    missing: List[str] = []
    conflicts: List[str] = []
    payload: Dict[str, Any] = {}
    data_date = None

    try:
        idx_res = fetch_index_kline(idx_keys, count=20)
        if isinstance(idx_res, dict) and idx_res.get("data_status") != "unavailable" and not idx_res.get("error"):
            payload["indices"] = idx_res.get("indices", {})
            data_date = index_latest_date(idx_res)
        else:
            missing.append("indices")
    except Exception as exc:
        missing.append(f"indices({exc})")

    try:
        sent_res = fetch_market_sentiment(date_str)
        if isinstance(sent_res, dict) and sent_res.get("data_status") != "unavailable" and not sent_res.get("error"):
            payload["sentiment"] = sent_res
            if not data_date:
                data_date = sent_res.get("date")
        else:
            missing.append("sentiment")
    except Exception as exc:
        missing.append(f"sentiment({exc})")

    try:
        ladder_res = fetch_limit_up_ladder(date_str)
        if isinstance(ladder_res, dict) and ladder_res.get("data_status") != "unavailable" and not ladder_res.get("error"):
            payload["ladder_summary"] = {
                "max_height": ladder_res.get("max_height"),
                "total_limit_up": ladder_res.get("total_limit_up"),
                "ladder_distribution": ladder_res.get("ladder_distribution", {}),
                "highest_tier_stocks": ladder_res.get("highest_tier_stocks", []),
            }
        else:
            missing.append("ladder")
    except Exception as exc:
        missing.append(f"ladder({exc})")

    try:
        breadth_res = fetch_market_breadth(days=2)
        if isinstance(breadth_res, dict) and breadth_res.get("data_status") != "unavailable" and not breadth_res.get("error"):
            payload["breadth"] = breadth_res
        else:
            missing.append("breadth")
    except Exception as exc:
        missing.append(f"breadth({exc})")

    if sectors and isinstance(sectors, list):
        sector_results = {}
        for s in sectors:
            if isinstance(s, str) and s.strip():
                try:
                    q_res = fetch_sector_limit_quality(s.strip(), date_str)
                    if isinstance(q_res, dict) and not q_res.get("error"):
                        sector_results[s.strip()] = q_res
                except Exception:
                    pass
        if sector_results:
            payload["sectors_preview"] = sector_results

    return _make_context_envelope("Preopen", payload, missing, conflicts, data_date)


def fetch_close_review_context(
    date_str: Optional[str] = None,
    top_sectors_count: int = 5,
) -> Dict[str, Any]:
    """聚合 A 股收盘复盘标准化证据包：收盘核心指数、情绪指标、广度红盘率、主力资金板块及领头封板质量"""
    missing: List[str] = []
    conflicts: List[str] = []
    payload: Dict[str, Any] = {}
    data_date = None

    try:
        idx_res = fetch_index_kline(["SHCI", "SZCI", "CYB", "CSIALL", "HS300"], count=2)
        if isinstance(idx_res, dict) and idx_res.get("data_status") != "unavailable" and not idx_res.get("error"):
            payload["indices"] = idx_res.get("indices", {})
            data_date = index_latest_date(idx_res)
        else:
            missing.append("indices")
    except Exception as exc:
        missing.append(f"indices({exc})")

    try:
        sent_res = fetch_market_sentiment(date_str)
        if isinstance(sent_res, dict) and sent_res.get("data_status") != "unavailable" and not sent_res.get("error"):
            payload["sentiment"] = sent_res
            if not data_date:
                data_date = sent_res.get("date")
        else:
            missing.append("sentiment")
    except Exception as exc:
        missing.append(f"sentiment({exc})")

    try:
        breadth_res = fetch_market_breadth(days=2)
        if isinstance(breadth_res, dict) and breadth_res.get("data_status") != "unavailable" and not breadth_res.get("error"):
            payload["breadth"] = breadth_res
        else:
            missing.append("breadth")
    except Exception as exc:
        missing.append(f"breadth({exc})")

    try:
        fund_res = fetch_sector_fund_flow(count=max(top_sectors_count, 1), days=1)
        if isinstance(fund_res, dict) and fund_res.get("data_status") != "unavailable" and not fund_res.get("error"):
            payload["top_fund_flow_sectors"] = fund_res.get("top_inflow_sectors", []) or fund_res.get("top_gainer_sectors", []) or fund_res.get("rankings", [])
        else:
            missing.append("sector_fund_flow")
    except Exception as exc:
        missing.append(f"sector_fund_flow({exc})")

    try:
        ladder_res = fetch_limit_up_ladder(date_str)
        if isinstance(ladder_res, dict) and ladder_res.get("data_status") != "unavailable" and not ladder_res.get("error"):
            payload["limit_up_ladder"] = ladder_res
        else:
            missing.append("ladder")
    except Exception as exc:
        missing.append(f"ladder({exc})")

    try:
        lhb_res = fetch_longhubang_detail(date_str=date_str)
        if isinstance(lhb_res, dict) and lhb_res.get("data_status") != "unavailable" and not lhb_res.get("error"):
            payload["longhubang"] = lhb_res
        else:
            missing.append("longhubang")
    except Exception as exc:
        missing.append(f"longhubang({exc})")

    rankings = payload.get("top_fund_flow_sectors", [])
    if rankings:
        sampled_qualities = {}
        for item in rankings[:2]:
            sec_name = item.get("sector_name") or item.get("name")
            if sec_name:
                try:
                    q = fetch_sector_limit_quality(sec_name, date_str)
                    if isinstance(q, dict) and not q.get("error"):
                        sampled_qualities[sec_name] = q
                except Exception:
                    pass
        if sampled_qualities:
            payload["mainline_limit_quality"] = sampled_qualities

    indices_data = payload.get("indices", {})
    sh_info = indices_data.get("SHCI", {}) or indices_data.get("sh000001", {})
    breadth_data = payload.get("breadth", {})
    if sh_info and breadth_data:
        sh_chg = safe_float(str(sh_info.get("change_pct", "")).rstrip("%"), None)
        red_ratio = breadth_red_ratio(breadth_data)
        if sh_chg is not None and red_ratio is not None:
            if sh_chg > 0.6 and red_ratio < 40.0:
                conflicts.append("指数明显上涨但全市场红盘率不足40%，呈现典型权重推升二八分化")
            elif sh_chg < -0.6 and red_ratio > 60.0:
                conflicts.append("指数明显下跌但红盘率超60%，呈现权重拖累中小题材活跃")

    return _make_context_envelope("Close_Review", payload, missing, conflicts, data_date)


ROTATION_WEIGHT_PLAN_5D = (0.05, 0.05, 0.20, 0.30, 0.40)


def _rotation_weights(days: int) -> List[float]:
    """按 T-days+1 至 T 生成归一化的近期加权权重（近期权重不低于远期）。

    days<=5 直接截取 5 日基准计划的后 days 段；days>5（调用方允许 2..10）则以 5 日计划
    的首尾权重 (0.05, 0.40) 为端点做线性内插，保证单调递增与归一化。该分支可达，
    并非死代码，由 test_rotation_context_weight_monotonic_and_gate 的 2..10 用例覆盖。
    """
    if days <= len(ROTATION_WEIGHT_PLAN_5D):
        base = list(ROTATION_WEIGHT_PLAN_5D[-days:])
    else:
        step = (ROTATION_WEIGHT_PLAN_5D[-1] - ROTATION_WEIGHT_PLAN_5D[0]) / (days - 1)
        base = [ROTATION_WEIGHT_PLAN_5D[0] + step * index for index in range(days)]
    total = sum(base)
    return [round(weight / total, 6) for weight in base]


def _describe_ma_alignment(kline_res: Dict[str, Any]) -> str:
    """根据均线与最新收盘价的相对位置描述板块多周期趋势级别。"""
    close = kline_res.get("latest_close")
    ma5 = kline_res.get("ma5")
    ma20 = kline_res.get("ma20")
    ma60 = kline_res.get("ma60")
    if close is None or ma20 is None:
        return "N/A"
    above_5 = ma5 is not None and close >= ma5
    above_20 = close >= ma20
    above_60 = ma60 is not None and close >= ma60
    if above_5 and above_20 and above_60:
        return "bullish_alignment: 收盘价站上 5/20/60 日均线，多周期趋势向上"
    if above_20 and above_60:
        return "above_ma20_ma60: 收盘价站上 20/60 日均线，中期趋势未破"
    if above_20:
        return "above_ma20_only: 仅站上 20 日均线，趋势待确认"
    if not above_20 and not above_60:
        return "below_ma20_ma60: 跌破 20/60 日均线，中期趋势走弱"
    return "mixed: 均线排列分歧，需结合量能确认"


def fetch_rotation_context(
    days: int = 5,
    sector_count: int = 10,
) -> Dict[str, Any]:
    """聚合 A 股 N 日板块轮动标准化证据包。

    payload 固定包含 5 个板块：
    - sector_fund_flows      行业主力净流入/净流出与涨幅榜（东财行业口径）
    - index_trend            核心宽基指数走势对比
    - breadth_trend          市场广度 / 红盘率序列
    - dominant_sectors_kline 核心主线板块 5/20/60 日区间涨幅与均线排列（逐板块聚合）
    - coverage_audit         计划权重、分块覆盖与量化评分门槛判定
    """
    missing: List[str] = []
    conflicts: List[str] = []
    payload: Dict[str, Any] = {}
    data_date = None

    try:
        fund_res = fetch_sector_fund_flow(count=sector_count, days=days)
        if isinstance(fund_res, dict) and fund_res.get("data_status") != "unavailable" and not fund_res.get("error"):
            payload["sector_fund_flows"] = fund_res
        else:
            missing.append("sector_fund_flows")
    except Exception as exc:
        missing.append(f"sector_fund_flows({exc})")

    try:
        idx_res = fetch_index_kline(["SHCI", "CYB", "CSIALL"], count=days)
        if isinstance(idx_res, dict) and idx_res.get("data_status") != "unavailable" and not idx_res.get("error"):
            payload["index_trend"] = idx_res.get("indices", {})
            # 交易日期一律以指数K线的真实最新交易日为准；资金流信封只带采集 timestamp，不能当交易日。
            data_date = data_date or index_latest_date(idx_res)
        else:
            missing.append("index_trend")
    except Exception as exc:
        missing.append(f"index_trend({exc})")

    try:
        breadth_res = fetch_market_breadth(days=days)
        if isinstance(breadth_res, dict) and breadth_res.get("data_status") != "unavailable" and not breadth_res.get("error"):
            payload["breadth_trend"] = breadth_res
        else:
            missing.append("breadth_trend")
    except Exception as exc:
        missing.append(f"breadth_trend({exc})")

    # 核心主线板块量价结构：取净流入前列板块，逐板块补 5/20/60 日区间涨幅与均线排列
    dominant_sectors: List[Dict[str, Any]] = []
    dominant_failed: List[str] = []
    fund_payload = payload.get("sector_fund_flows") or {}
    leader_names = [
        item.get("name")
        for item in (fund_payload.get("top_inflow_sectors") or [])
        if isinstance(item, dict) and item.get("name")
    ][: min(sector_count, 5)]
    for name in leader_names:
        try:
            kline_res = fetch_sector_kline(name, count=max(60, days))
        except Exception:
            dominant_failed.append(name)
            continue
        if not isinstance(kline_res, dict) or kline_res.get("error") or kline_res.get("data_status") == "unavailable":
            dominant_failed.append(name)
            continue
        dominant_sectors.append({
            "name": kline_res.get("sector_name") or name,
            "code": kline_res.get("sector_code"),
            "data_status": kline_res.get("data_status"),
            "valid_bars": kline_res.get("valid_bars"),
            "recent_5d_return": kline_res.get("recent_5d_return"),
            "recent_20d_return": kline_res.get("recent_20d_return"),
            "recent_60d_return": kline_res.get("recent_60d_return"),
            "ma5": kline_res.get("ma5"),
            "ma10": kline_res.get("ma10"),
            "ma20": kline_res.get("ma20"),
            "ma60": kline_res.get("ma60"),
            "latest_close": kline_res.get("latest_close"),
            "avg_amount_5d_billion": kline_res.get("avg_amount_5d_billion"),
            "ma_alignment": _describe_ma_alignment(kline_res),
        })
    if dominant_sectors:
        payload["dominant_sectors_kline"] = {
            "sectors": dominant_sectors,
            "failed_sectors": dominant_failed,
            "note": "均线排列由 ma5/ma10/ma20/ma60 与最新收盘价推导，用于判定多周期趋势级别；口径为东财行业板块指数。",
        }
    else:
        missing.append("dominant_sectors_kline")

    # 覆盖率审计：计划权重 + 分块覆盖 + 量化评分门槛
    planned_sections = ("sector_fund_flows", "index_trend", "breadth_trend", "dominant_sectors_kline")
    available_sections = [name for name in planned_sections if name in payload]
    section_coverage = len(available_sections) / len(planned_sections) * 100.0
    # 量化门槛：分块覆盖率 >= 70% 且核心主线板块量价块（dominant_sectors_kline）在位。
    # 缺少主线块时，即便其余三块齐全（75%）也不得输出精确量化分，避免在无主线证据下给出轮动评分。
    mainline_ready = "dominant_sectors_kline" in payload
    score_ready = section_coverage >= 70.0 and mainline_ready
    if score_ready:
        gate_note = "分块覆盖率 >= 70% 且主线板块量价块在位，可输出 5 日量化分。"
    elif not mainline_ready:
        gate_note = "缺少 dominant_sectors_kline 主线板块量价块，按公共契约禁止输出 5 日精确量化分，仅输出定性观察与待补清单。"
    else:
        gate_note = "分块覆盖率 < 70%，按公共契约禁止输出 5 日精确量化分，仅输出定性观察与待补清单。"
    payload["coverage_audit"] = {
        "planned_days": days,
        "planned_weights": _rotation_weights(days),
        "weight_order": f"T-{days - 1} 至 T（近期权重不低于远期，合计归一化为 1）",
        "sections_planned": list(planned_sections),
        "sections_available": available_sections,
        "section_coverage_pct": round(section_coverage, 2),
        "mainline_block_present": mainline_ready,
        "score_gate": "enabled" if score_ready else "disabled_qualitative_only",
        "gate_note": gate_note,
    }

    return _make_context_envelope("Rotation", payload, missing, conflicts, data_date)


def fetch_stock_diagnostic_context(
    symbol: str,
    benchmark: str = "CSIALL",
    sector: Optional[str] = None,
    archetype_hints: Optional[Dict[str, Any]] = None,
    position_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """聚合个股证据并预计算数据模式、生态分型、威科夫适用性和持仓场景。"""
    missing: List[str] = []
    conflicts: List[str] = []
    payload: Dict[str, Any] = {}
    data_date = None

    try:
        quote_res = fetch_stock_quote(symbol)
        if isinstance(quote_res, dict) and quote_res.get("data_status") != "unavailable" and not quote_res.get("error"):
            payload["quote"] = quote_res
            data_date = normalize_date(quote_res.get("as_of"))
        else:
            missing.append("quote")
    except Exception as exc:
        missing.append(f"quote({exc})")

    try:
        kline_res = fetch_stock_kline(symbol, count=750, compact=True)
        if isinstance(kline_res, dict) and kline_res.get("data_status") != "unavailable" and not kline_res.get("error"):
            payload["kline_structure"] = kline_res
            if not data_date:
                data_date = normalize_date(kline_res.get("latest_date"))
        else:
            missing.append("kline_structure")
    except Exception as exc:
        missing.append(f"kline_structure({exc})")

    try:
        quality_res = fetch_company_quality(symbol)
        if isinstance(quality_res, dict) and quality_res.get("data_status") != "unavailable" and not quality_res.get("error"):
            payload["company_quality"] = quality_res
        else:
            missing.append("company_quality")
    except Exception as exc:
        missing.append(f"company_quality({exc})")

    try:
        timeline_res = fetch_stock_timeline(symbol)
        if isinstance(timeline_res, dict) and timeline_res.get("data_status") != "unavailable" and not timeline_res.get("error"):
            payload["timeline"] = timeline_res
        else:
            missing.append("timeline")
    except Exception as exc:
        missing.append(f"timeline({exc})")

    try:
        lhb_res = fetch_longhubang_detail(symbol=symbol)
        if isinstance(lhb_res, dict) and not lhb_res.get("error"):
            payload["longhubang"] = lhb_res
        else:
            payload["longhubang"] = {"status": "none", "message": "近期无公开龙虎榜异动"}
    except Exception:
        payload["longhubang"] = {"status": "unavailable", "message": "龙虎榜接口暂时不可用"}

    try:
        bm_key = benchmark or "CSIALL"
        idx_res = fetch_index_kline([bm_key], count=130)
        if isinstance(idx_res, dict) and idx_res.get("data_status") != "unavailable" and not idx_res.get("error"):
            payload["benchmark_kline"] = idx_res.get("indices", {})
        else:
            missing.append("benchmark_kline")
    except Exception as exc:
        missing.append(f"benchmark_kline({exc})")

    if sector:
        try:
            sector_res = fetch_sector_kline(sector, count=130)
            if isinstance(sector_res, dict) and sector_res.get("data_status") != "unavailable" and not sector_res.get("error"):
                payload["sector_kline"] = sector_res
            else:
                missing.append("sector_kline")
        except Exception as exc:
            missing.append(f"sector_kline({exc})")
    else:
        missing.append("sector_kline(sector_not_provided)")

    kline = payload.get("kline_structure", {})
    quote = payload.get("quote", {})
    timeline = payload.get("timeline", {})
    hints = dict(archetype_hints or {})
    turnover = safe_float(str(quote.get("turnover_rate", "")).rstrip("%"), None)
    weekly = kline.get("weekly_timeframe", {}) if isinstance(kline, dict) else {}
    financial = (payload.get("company_quality", {}) or {}).get("financial_summary", {})
    earnings_growth = safe_float(str(financial.get("net_profit_yoy", "")).rstrip("%"), None)
    hints.setdefault("turnover_rate", turnover)
    hints.setdefault("trend_alignment", weekly.get("weekly_alignment"))
    hints.setdefault("earnings_growth", earnings_growth)

    data_mode = resolve_stock_data_mode(
        bar_count=kline.get("valid_bars"),
        adjusted=kline.get("adjustment") == "qfq",
        benchmark_complete=bool(payload.get("benchmark_kline")),
        industry_complete=bool(payload.get("sector_kline")),
        days_listed=hints.get("days_listed"),
        event_driven=bool(hints.get("event_driven", False)),
        resumed_recently=bool(hints.get("resumed_recently", False)),
        quote_available=bool(quote), timeline_available=bool(timeline),
        turnover_available=turnover is not None,
    )
    payload["data_mode"] = data_mode

    archetype = classify_stock_archetype(**{
        key: hints.get(key) for key in (
            "limit_up_streak", "recent_limit_up_count", "turnover_rate", "sector_role",
            "trend_alignment", "institutional_net_buy", "earnings_growth", "dividend_yield",
            "payout_stable", "operating_cashflow_positive", "event_driven", "resumed_recently", "days_listed",
        )
    })
    payload["archetype"] = archetype
    if archetype.get("value") != "N/A":
        payload["selected_model"] = select_stock_model(
            archetype["value"]["archetype"], data_mode["value"]["mode"]
        )
    else:
        missing.append("archetype_evidence")

    payload["wyckoff_applicability"] = assess_wyckoff_applicability(
        data_mode["value"]["mode"], range_days=hints.get("range_days"),
        limit_up_streak=hints.get("limit_up_streak"),
        event_driven=bool(hints.get("event_driven", False)),
        one_word_limit_days=hints.get("one_word_limit_days"),
    )
    allowed_position_fields = {
        "position_state", "cost_price", "position_ratio", "holding_horizon", "risk_tolerance"
    }
    position_args = {
        key: value for key, value in (position_context or {}).items()
        if key in allowed_position_fields
    }
    payload["position_context"] = validate_position_context(**position_args)

    lhb = payload.get("longhubang", {})
    seat_entries = []
    if isinstance(lhb, dict):
        for key in ("buy_seats", "sell_seats", "org_seat_net_details", "seats"):
            value = lhb.get(key)
            if isinstance(value, list):
                seat_entries.extend(item for item in value if isinstance(item, dict))
    payload["seat_evidence"] = summarize_seat_evidence(seat_entries)
    payload["chip_structure"] = {
        "status": "unavailable",
        "reason": "当前公开 MCP 未提供可审计筹码峰/获利盘分布；不得估算或用换手率替代",
    }

    # 核心真实数据块是否至少有一块可用。longhubang 恒有占位 dict（status=none/unavailable），
    # 不计入核心判定，避免「无龙虎榜」被误当作有数据。派生块（data_mode/archetype/
    # position_context 等）恒存在，因此不能作为可用性依据。
    core_data_keys = (
        "quote", "kline_structure", "company_quality",
        "timeline", "benchmark_kline", "sector_kline",
    )
    core_data_available = any(key in payload for key in core_data_keys)
    if not core_data_available:
        missing.append("core_data_unavailable")

    return _make_context_envelope(
        "Stock_Diagnostic", payload, missing, conflicts, data_date,
        core_data_available=core_data_available,
    )


# -----------------------------------------------------------------------------
# 3. 标准 MCP JSON-RPC 2.0 协议处理器 (stdio 管道)
# -----------------------------------------------------------------------------
SERVER_INFO = {
    "name": "marketgraph-data",
    "version": "2.4.0",
}

def _dispatch_tool_call(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(arguments, dict):
        return {"error": "arguments 必须是对象", "data_status": "unavailable"}
    if name in {"get_stock_quote", "get_stock_kline", "get_stock_timeline", "get_company_quality"}:
        if not isinstance(arguments.get("symbol"), str) or not arguments["symbol"].strip():
            return {"error": "symbol 必须是非空字符串", "data_status": "unavailable"}
    if name == "get_sector_kline":
        if not isinstance(arguments.get("sector"), str) or not arguments["sector"].strip():
            return {"error": "sector 必须是非空字符串", "data_status": "unavailable"}
        if arguments.get("count", 130) is not None and (not isinstance(arguments.get("count", 130), int) or not 20 <= arguments.get("count", 130) <= 250):
            return {"error": "count 必须是 20 至 250 的整数", "data_status": "unavailable"}
    if name == "get_sector_limit_quality":
        if not isinstance(arguments.get("sector"), str) or not arguments["sector"].strip():
            return {"error": "sector 必须是非空字符串", "data_status": "unavailable"}
    if name == "get_basket_index":
        stocks = arguments.get("stocks")
        if not isinstance(stocks, list) or len(stocks) < 2 or len(stocks) > 10 or not all(isinstance(s, str) and s.strip() for s in stocks):
            return {"error": "stocks 必须是 2 至 10 个非空字符串的数组", "data_status": "unavailable"}
        if arguments.get("count", 20) is not None and (not isinstance(arguments.get("count", 20), int) or not 5 <= arguments.get("count", 20) <= 60):
            return {"error": "count 必须是 5 至 60 的整数", "data_status": "unavailable"}
    if name == "get_sector_fund_flow" and (not isinstance(arguments.get("count", 20), int) or not 1 <= arguments.get("count", 20) <= 100):
        return {"error": "count 必须是 1 至 100 的整数", "data_status": "unavailable"}
    if name == "get_index_kline" and arguments.get("count", 5) is not None and (not isinstance(arguments.get("count", 5), int) or not 2 <= arguments.get("count", 5) <= 130):
        return {"error": "count 必须是 2 至 130 的整数", "data_status": "unavailable"}
    if name == "get_market_breadth" and arguments.get("days", 5) is not None and (not isinstance(arguments.get("days", 5), int) or not 2 <= arguments.get("days", 5) <= 10):
        return {"error": "days 必须是 2 至 10 的整数", "data_status": "unavailable"}
    if name == "get_index_kline" and arguments.get("indices") is not None and (
        not isinstance(arguments.get("indices"), list) or not all(isinstance(x, str) for x in arguments["indices"])
    ):
        return {"error": "indices 必须是字符串数组", "data_status": "unavailable"}
    if name == "get_stock_diagnostic_context":
        if not isinstance(arguments.get("symbol"), str) or not arguments["symbol"].strip():
            return {"error": "symbol 必须是非空字符串", "data_status": "unavailable"}
        for field in ("archetype_hints", "position_context"):
            if arguments.get(field) is not None and not isinstance(arguments[field], dict):
                return {"error": f"{field} 必须是对象", "data_status": "unavailable"}
    if name == "get_rotation_context":
        if arguments.get("days", 5) is not None and (not isinstance(arguments.get("days", 5), int) or not 2 <= arguments.get("days", 5) <= 10):
            return {"error": "days 必须是 2 至 10 的整数", "data_status": "unavailable"}
        if arguments.get("sector_count", 10) is not None and (not isinstance(arguments.get("sector_count", 10), int) or not 1 <= arguments.get("sector_count", 10) <= 50):
            return {"error": "sector_count 必须是 1 至 50 的整数", "data_status": "unavailable"}
    if name == "get_close_review_context":
        if arguments.get("top_sectors_count", 5) is not None and (not isinstance(arguments.get("top_sectors_count", 5), int) or not 1 <= arguments.get("top_sectors_count", 5) <= 20):
            return {"error": "top_sectors_count 必须是 1 至 20 的整数", "data_status": "unavailable"}
    if name == "get_preopen_context":
        if arguments.get("indices") is not None and (
            not isinstance(arguments.get("indices"), list) or not all(isinstance(x, str) for x in arguments["indices"])
        ):
            return {"error": "indices 必须是字符串数组", "data_status": "unavailable"}
        if arguments.get("sectors") is not None and (
            not isinstance(arguments.get("sectors"), list) or not all(isinstance(x, str) for x in arguments["sectors"])
        ):
            return {"error": "sectors 必须是字符串数组", "data_status": "unavailable"}
    if name == "save_artifact" and not isinstance(arguments.get("artifact"), dict):
        return {"error": "artifact 必须是对象", "data_status": "unavailable"}
    if name == "load_artifact" and not any(arguments.get(key) for key in ("snapshot_id", "artifact_type", "trading_date", "subject")):
        return {"error": "至少提供 snapshot_id 或一个筛选条件", "data_status": "unavailable"}
    if name == "evaluate_prediction" and not all(
        isinstance(arguments.get(key), str) and arguments[key].strip()
        for key in ("prediction_snapshot_id", "actual_snapshot_id")
    ):
        return {"error": "prediction_snapshot_id 和 actual_snapshot_id 必须是非空字符串", "data_status": "unavailable"}
    if name == "get_stock_quote":
        return fetch_stock_quote(arguments.get("symbol", ""))
    elif name == "get_stock_kline":
        return fetch_stock_kline(
            arguments.get("symbol", ""),
            arguments.get("count", 750),
            arguments.get("compact", True)
        )
    elif name == "get_stock_timeline":
        return fetch_stock_timeline(arguments.get("symbol", ""))
    elif name == "get_market_sentiment":
        return fetch_market_sentiment(arguments.get("date_str"))
    elif name == "get_limit_up_ladder":
        return fetch_limit_up_ladder(arguments.get("date_str"))
    elif name == "get_sector_limit_quality":
        return fetch_sector_limit_quality(arguments.get("sector", ""), arguments.get("date_str"))
    elif name == "get_index_kline":
        return fetch_index_kline(arguments.get("indices"), arguments.get("count", 5))
    elif name == "get_market_breadth":
        return fetch_market_breadth(arguments.get("days", 5))
    elif name == "get_sector_fund_flow":
        return fetch_sector_fund_flow(arguments.get("count", 20), arguments.get("days", 1))
    elif name == "get_sector_kline":
        return fetch_sector_kline(arguments.get("sector", ""), arguments.get("count", 130))
    elif name == "get_basket_index":
        return fetch_basket_index(arguments.get("stocks", []), arguments.get("count", 20))
    elif name == "get_longhubang_detail":
        return fetch_longhubang_detail(arguments.get("symbol"), arguments.get("date_str"))
    elif name == "get_company_quality":
        return fetch_company_quality(arguments.get("symbol", ""))
    elif name == "get_preopen_context":
        return fetch_preopen_context(
            arguments.get("indices"),
            arguments.get("date_str"),
            arguments.get("sectors"),
        )
    elif name == "get_close_review_context":
        return fetch_close_review_context(
            arguments.get("date_str"),
            arguments.get("top_sectors_count", 5),
        )
    elif name == "get_rotation_context":
        return fetch_rotation_context(
            arguments.get("days", 5),
            arguments.get("sector_count", 10),
        )
    elif name == "get_stock_diagnostic_context":
        return fetch_stock_diagnostic_context(
            arguments.get("symbol", ""),
            arguments.get("benchmark", "CSIALL"),
            arguments.get("sector"),
            arguments.get("archetype_hints"),
            arguments.get("position_context"),
        )
    elif name == "save_artifact":
        return save_artifact_tool(arguments["artifact"])
    elif name == "load_artifact":
        return load_artifact_tool(
            arguments.get("snapshot_id"),
            artifact_type=arguments.get("artifact_type"),
            trading_date=arguments.get("trading_date"),
            subject=arguments.get("subject"),
        )
    elif name == "evaluate_prediction":
        return evaluate_prediction_tool(
            arguments["prediction_snapshot_id"], arguments["actual_snapshot_id"]
        )
    elif name == "render_report":
        return render_report_tool(
            snapshot_id=arguments.get("snapshot_id"),
            report_type=arguments.get("report_type"),
            report_data=arguments.get("report_data"),
            theme=arguments.get("theme", "light"),
            output_format=arguments.get("output_format", "png"),
            output_name=arguments.get("output_name"),
        )
    else:
        return {"error": f"未知工具: {name}"}


def response_envelope(result: Dict[str, Any]) -> Dict[str, Any]:
    """增加 v2 标准信封，同时保留旧顶层字段供已安装客户端兼容读取。"""
    legacy = dict(result) if isinstance(result, dict) else {"value": result}
    error = legacy.get("error")
    warnings = legacy.get("warnings", [])
    if isinstance(warnings, str):
        warnings = [warnings]
    status = legacy.get("data_status") or ("unavailable" if error else "ok")
    source = str(legacy.get("source") or "marketgraph-data")
    as_of = legacy.get("as_of") or legacy.get("timestamp") or legacy.get("latest_date") or legacy.get("date")
    enriched = dict(legacy)
    enriched.update({
        "api_version": "2.0",
        "source": source,
        "data_status": status,
        "as_of": as_of,
        "data": legacy,
        "errors": [str(error)] if error else [],
        "warnings": list(warnings),
        "legacy_fields_retained": True,
    })
    return enriched


def handle_tool_call(name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
    return response_envelope(_dispatch_tool_call(name, arguments))


def run_stdio_server():
    """标准 MCP stdio 消息循环 (JSON-RPC 2.0)"""
    sys.stderr.write("[MarketGraph-MCP] 服务已启动，正在监听 stdio JSON-RPC...\n")
    sys.stderr.flush()

    while True:
        line = sys.stdin.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue

        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}) + "\n")
            sys.stdout.flush()
            continue

        if not isinstance(req, dict) or req.get("jsonrpc") != "2.0":
            sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid Request"}}) + "\n")
            sys.stdout.flush()
            continue

        msg_id = req.get("id")
        method = req.get("method")

        # 1. 握手与初始化 (initialize)
        if method == "initialize":
            res = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {},
                    },
                    "serverInfo": SERVER_INFO,
                },
            }
            sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
            sys.stdout.flush()

        # 2. 客户端完成通知 (notifications/initialized)
        elif method == "notifications/initialized":
            pass

        # 3. 列出工具 (tools/list)
        elif method == "tools/list":
            res = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "tools": AVAILABLE_TOOLS,
                },
            }
            sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
            sys.stdout.flush()

        # 4. 执行工具调用 (tools/call)
        elif method == "tools/call":
            params = req.get("params", {})
            name = params.get("name")
            arguments = params.get("arguments", {})
            tool_res = handle_tool_call(name, arguments)

            res = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(tool_res, ensure_ascii=False, indent=2),
                        }
                    ],
                    "isError": "error" in tool_res,
                },
            }
            sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
            sys.stdout.flush()

        # 5. 心跳检测 (ping)
        elif method == "ping":
            res = {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {},
            }
            sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
            sys.stdout.flush()

        else:
            if msg_id is not None:
                res = {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {method}",
                    },
                }
                sys.stdout.write(json.dumps(res, ensure_ascii=False) + "\n")
                sys.stdout.flush()


# -----------------------------------------------------------------------------
# 4. 命令行直接测试模式 (方便开发者免配置验证)
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        tool_name = sys.argv[2] if len(sys.argv) > 2 else "get_stock_quote"
        target_symbol = sys.argv[3] if len(sys.argv) > 3 else "300308"
        print(f"[*] 正在本地直接调试工具: {tool_name} (标的: {target_symbol})")
        if tool_name == "get_stock_quote":
            out = fetch_stock_quote(target_symbol)
        elif tool_name == "get_stock_kline":
            is_compact = True if len(sys.argv) <= 4 or sys.argv[4] != "full" else False
            out = fetch_stock_kline(target_symbol, 750, compact=is_compact)
        elif tool_name == "get_stock_timeline":
            out = fetch_stock_timeline(target_symbol)
        elif tool_name == "get_market_sentiment":
            out = fetch_market_sentiment()
        elif tool_name == "get_limit_up_ladder":
            out = fetch_limit_up_ladder()
        elif tool_name == "get_sector_limit_quality":
            # --test 默认标的是个股代码, 板块工具需独立默认板块名
            out = fetch_sector_limit_quality(sys.argv[3] if len(sys.argv) > 3 else "半导体")
        elif tool_name == "get_index_kline":
            out = fetch_index_kline()
        elif tool_name == "get_market_breadth":
            out = fetch_market_breadth()
        elif tool_name == "get_sector_fund_flow":
            days = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3].isdigit() else 1
            out = fetch_sector_fund_flow(10 if days > 1 else 20, days)
        elif tool_name == "get_sector_kline":
            # --test 默认标的是个股代码, 板块工具需独立默认板块名
            out = fetch_sector_kline(sys.argv[3] if len(sys.argv) > 3 else "半导体")
        elif tool_name == "get_basket_index":
            default_stocks = ["601318", "601628", "601601", "601366"]  # 保险板块四大成分
            stocks = sys.argv[3].split(",") if len(sys.argv) > 3 and sys.argv[3].strip() else default_stocks
            out = fetch_basket_index(stocks)
        elif tool_name == "get_longhubang_detail":
            out = fetch_longhubang_detail(target_symbol)
        elif tool_name == "get_company_quality":
            out = fetch_company_quality(target_symbol)
        elif tool_name == "get_preopen_context":
            out = fetch_preopen_context()
        elif tool_name == "get_close_review_context":
            out = fetch_close_review_context()
        elif tool_name == "get_rotation_context":
            out = fetch_rotation_context()
        elif tool_name == "get_stock_diagnostic_context":
            out = fetch_stock_diagnostic_context(target_symbol)
        else:
            out = {"error": "未知工具"}
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        run_stdio_server()
